// Implementation of the CLcmMdl class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"


CLcmMdl::CLcmMdl()				{				}
CLcmMdl::~CLcmMdl()				{				}

INT	 CLcmMdl::Create(void*,void*,void*,void*){ return -1;	}
void CLcmMdl::Destroy()			{				}
INT  CLcmMdl::FrameMove()		{	return 0;	}
void CLcmMdl::Render()			{				}



