// Interface for the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif


#ifndef _LcMax_H_
#define _LcMax_H_

#pragma warning(disable: 4530)
#pragma warning(disable: 4786)

#include <vector>
#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")


#define LCMAX_CLASS_ID	Class_ID(0x4228b838, 0xe0b3452)



typedef D3DXMATRIX		MATA;




struct VtxIdx
{
	WORD a, b, c;

	VtxIdx() : a(0), b(1), c(2){}
	VtxIdx(WORD A,WORD B,WORD C) : a(A), b(B), c(C){}
};


struct VtxPos
{
	FLOAT x, y, z;

	VtxPos() : x(0), y(1), z(2){}
	VtxPos(FLOAT X,FLOAT Y,FLOAT Z) : x(X), y(Y), z(Z){}
};


// Geometry Type
enum ELcGeo
{
	LCX_ETC		=0,
	LCX_MESH	=1,
	LCX_BONE	=2,

	LCX_HDEADER_OFFSET	= 64,
};



struct LcGeo
{
	char			sName[32];	// Node Name
	INT				nType;		// 1:Geometry, 2: Bone, 0: Etc

	INode*			pNode;		// Node
	INT				nPrn;		// Parent Index

	D3DXMATRIX		mtLcl;		// Local Matrix

	INT				nFce;		// Number of Face
	INT				nPos;		// Number of Position
	VtxIdx*			pFce;		// Face List
	VtxPos*			pPos;		// Position List

	INT				nAni;		// Number of Animation
	D3DXMATRIX*		pAni;		// Animation Matrix

	LcGeo()
	{
		memset(sName, 0, sizeof sName);
		nType	= LCX_ETC;

		nPrn	= -1;					// �θ� ����
		D3DXMatrixIdentity(&mtLcl);		// ��������� ���� ��ķ� �����.

		nFce	= 0;
		nPos	= 0;
		pFce	= NULL;
		pPos	= NULL;

		pNode	= NULL;

		nAni	= 0;
		pAni	= NULL;
	}

	~LcGeo()
	{
		if(pFce){	delete [] pFce; pFce = NULL;	}
		if(pPos){	delete [] pPos; pPos = NULL;	}
		if(pAni){	delete [] pAni; pAni = NULL;	}
	}
};


struct LcHeader
{
	INT		nFrmB;					// Begin Frame
	INT		nFrmE;					// End Frame
	INT		nFrmP;					// Frame Rate(FPS)
	INT		nFrmT;					// Tick Frame

	INT		nGeo;					// Number of Geometry
	
	LcHeader()
	{
		nFrmB	= 0;
		nFrmE	= 0;
		nFrmP	= 0;
		nFrmT	= 0;

		nGeo	= 0;
	}
};


class LcMax : public SceneExport
{
public:
	LcMax();
	virtual ~LcMax();

	int				ExtCount();					// Number of extensions supported
	const TCHAR*	Ext(int n);					// Extension #n (i.e. "3DS")
	const TCHAR*	LongDesc();					// Long ASCII description (i.e. "Autodesk 3D Studio File")
	const TCHAR*	ShortDesc();				// Short ASCII description (i.e. "3D Studio")
	const TCHAR*	AuthorName();				// ASCII Author name
	const TCHAR*	CopyrightMessage();			// ASCII Copyright message
	const TCHAR*	OtherMessage1();			// Other message #1
	const TCHAR*	OtherMessage2();			// Other message #2
	unsigned int	Version();					// Version number * 100 (i.e. v3.01 = 301)
	void			ShowAbout(HWND hWnd);		// Show DLL's "About..." box
	
	BOOL			SupportsOptions(int ext, DWORD options);
	int				DoExport(const TCHAR*,ExpInterface*,Interface*, BOOL =FALSE, DWORD =0);


	static INT_PTR CALLBACK LcMaxOptionsDlgProc(HWND,UINT,WPARAM,LPARAM);

public:
	BOOL	m_bDoExport;
	
protected:
	ExpInterface*	m_pE;				// ExpInterface
	Interface*		m_pI;				// Interface
	BOOL			m_bS;				// Supress Prompt
	DWORD			m_dO;				// Options

	TCHAR			m_sFb[MAX_PATH];	// Export Binary File Name
	TCHAR			m_sFt[MAX_PATH];	// Export Text File Name
	TCHAR			m_sFl[MAX_PATH];	// Export Log File Name

	std::vector<INode*>	m_vMaxNode;		// �ƽ��� Node �ڷᱸ��

	LcHeader		m_Header;			// Header
	LcGeo*			m_pGeo;				// Geometry Data

protected:
	void	GatherNode(INode*);			// Gather Node

	void	SetupIsBone(LcGeo*);		// Bone or Not
	void	SetupParentIndex(LcGeo*);	// Setup Parent Index
	void	SetupLocalMatrix(LcGeo*);	// Setup Local Matrix
	void	SetupGeometry(LcGeo*);		// Setup Mesh
	void	SetupAnimation(LcGeo*);		// Setup Animation

	INT		FindBoneId(INode*);			// Get Index of Node matched Geometry

	void	WriteBinary();				// Export Binary
	void	WriteText();				// Export Text

	void	FileRename(char* pOut
				, char* pIn				// Original FullPath File Name
				, char* sFileName		// New File Name. if it is NULL, then The File Name will be Conserved.
				, char* sExt			// New Extension. if it is NULL, then The Extension will be Conserved.
				);


	void	MaxMatrixToD3D(D3DXMATRIX* pDst, Matrix3* pSrc, BOOL bIdentity=TRUE);

};



#endif

