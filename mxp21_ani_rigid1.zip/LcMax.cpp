// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#define SAFE_DELETE(p)		{ if(p){ delete  p; p = NULL;	}	}
#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] p; p = NULL;	}	}


#include "_StdAfx.h"


int	LcMax::DoExport(const TCHAR *sFile,ExpInterface *ei,Interface *pi, BOOL suppressPrompts, DWORD options)
{
	INT		n = 0;
	INT		i =0;

	HWND	hWndPrn = pi->GetMAXHWnd();// = GetActiveWindow();

	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_MAIN), hWndPrn, (DLGPROC)LcMaxOptionsDlgProc, (LPARAM)this);

	if(FALSE == m_bDoExport)
		return FALSE;


	m_pE	= ei;
	m_pI	= pi;
	m_bS	= suppressPrompts;
	m_dO	= options;


	// 0. Prepare: ���� �̸� ����
	memset(m_sFb, 0, sizeof m_sFb);	// Export Binary File Name
	memset(m_sFt, 0, sizeof m_sFt);	// Export Text File Name
	memset(m_sFl, 0, sizeof m_sFl);	// Export Log File Name
	strcpy(m_sFb, sFile);


	// �����̸� �ҹ��� ��ȯ
	char *s = (char*)sFile;
	char *e = (char*)sFile;
	char *d = (char*)m_sFb;

	e+= strlen( m_sFb );
	for( ; s<e; ++s, ++d)
		*d = tolower(*s);


	// 0. ���� �̸� ����
	FileRename(m_sFt, m_sFb, NULL, "act");
	FileRename(m_sFl, m_sFb, NULL, "acz");



	// 0. ����� ������ ������.
	int		 iTick = GetTicksPerFrame();
	Interval range = m_pI->GetAnimRange();

	m_Header.nFrmB = range.Start() / iTick;
	m_Header.nFrmE = range.End() / iTick;
	m_Header.nFrmP = GetFrameRate();			// FPS
	m_Header.nFrmT = iTick;



	// 1. Gather Node
	INode*	pRoot = m_pI->GetRootNode();
	GatherNode(pRoot);


	// 2. Create Geometry
	m_Header.nGeo = m_vMaxNode.size();
	if(m_Header.nGeo<1)
		return -1;

	m_pGeo = new LcGeo[m_Header.nGeo];

	
	// 3. Binding Bone to LcGeo
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		INode*	pNode = m_vMaxNode[n];
		pGeo->pNode	= pNode;

		TCHAR*	sName  = pNode->GetName();
		sprintf(pGeo->sName, sName);
	}


	// 4. Bone or Not
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupIsBone(pGeo);
	}


	// 5. Setup Parent Index
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupParentIndex(pGeo);
	}


	// 6. Setup Local Matrix
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupLocalMatrix(pGeo);
	}


	// 7. Setup Geometry
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupGeometry(pGeo);
	}

	// 8. Setup Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupAnimation(pGeo);
	}


	// 9. ���� ���
	WriteBinary();
	WriteText();


	SAFE_DELETE_ARRAY(	m_pGeo	);
	m_bDoExport = FALSE;
	return TRUE;
}


void LcMax::GatherNode(INode* pNode)
{
	if(!pNode)
		return;

	m_vMaxNode.push_back(pNode);

	INT iChild = pNode->NumberOfChildren();

	for(int i=0; i<iChild; ++i)
	{
		INode* pChild = pNode->GetChildNode(i);

		if(pChild)
			GatherNode(pChild);
	}
}



void LcMax::SetupIsBone(LcGeo* pGeo)
{
	INode*	pNode = pGeo->pNode;

	if(NULL == pNode)
		return ;


	ObjectState os = pNode->EvalWorldState(0);

	if (!os.obj)
		return;

	if( 0 == _strnicmp(pNode->GetName(), "Bone", 4) ||
		0 == _strnicmp(pNode->GetName(), "Bip", 3))
	{
		pGeo->nType = LCX_BONE;
		return;
	}

	if(	os.obj->ClassID() == Class_ID(BONE_CLASS_ID, 0) ||
		os.obj->ClassID() == BONE_OBJ_CLASSID ||
		os.obj->ClassID() == Class_ID(DUMMY_CLASS_ID, 0) )
	{
		pGeo->nType = LCX_BONE;
		return;
	}


	Control *cont = pNode->GetTMController();
	if(cont->ClassID() == BIPSLAVE_CONTROL_CLASS_ID ||		//others biped parts
		cont->ClassID() == BIPBODY_CONTROL_CLASS_ID	||		//biped root "Bip01"
		cont->ClassID() == FOOTPRINT_CLASS_ID				//Bip01 Footsteps
		)
		pGeo->nType = LCX_BONE;
}


void LcMax::SetupParentIndex(LcGeo* pGeo)
{
	INode*	pNode = pGeo->pNode;
	INode*	pPrn = pNode->GetParentNode();

	if(pPrn)
		pGeo->nPrn = FindBoneId(pPrn);
}


void LcMax::SetupLocalMatrix(LcGeo* pGeo)
{
	INode*	pNode = pGeo->pNode;
	INode*	pPrnt = pNode->GetParentNode();

	Matrix3 tmLocal;
	Matrix3 tmWorld = pNode->GetObjTMAfterWSM(0);

	if(!pPrnt)
		tmLocal = tmWorld;
	else
	{
		Matrix3 tmParent= pPrnt->GetObjTMAfterWSM(0);
		tmLocal = tmWorld * Inverse(tmParent);
	}

	MaxMatrixToD3D(&pGeo->mtLcl, &tmLocal);
}


void LcMax::SetupGeometry(LcGeo* pGeo)
{
	INT		i;

	INode*	pNode = pGeo->pNode;
	TCHAR*	sName = pNode->GetName();

	Object* pObj = pNode->EvalWorldState(0).obj;

	if(!pObj)
		return;

	SClass_ID lSuperID = pObj->SuperClassID();
	Class_ID lClassID = pObj->ClassID();


	if(GEOMOBJECT_CLASS_ID != lSuperID)
		return;

	// �޽��� �ﰢ������ �ٲ� �� �ִ°�?
//	if(!pObj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
//		return;

	// �ﰢ������ �޽��� �ٲ۴�.
	TriObject* pTri = (TriObject *)pObj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	if(NULL == pTri)
		return;

	// �޽� ��ü�� ��´�.
	Mesh* pMesh	= &pTri->GetMesh();
	if(NULL ==pMesh)
		return;


	// �ε����� ������ ���ڸ� ��´�.
	INT	iNfce	= pMesh->getNumFaces();
	INT	iNvtx	= pMesh->getNumVerts();

	// Setup Index and Vertex Number
	pGeo->nFce = iNfce;
	pGeo->nPos = iNvtx;

	// �ε����� ������ ������ ���� ������.
	if(iNfce <=0 || iNvtx <=0)
		return;


	// Setup Type
	if(LCX_BONE != pGeo->nType)
		pGeo->nType = LCX_MESH;


	// Index Vertex ����
	pGeo->pFce = new VtxIdx[iNfce];
	pGeo->pPos = new VtxPos[iNvtx];


	// �ε��� ������ ����
	for (i=0; i<iNfce; ++i)
	{
		pGeo->pFce[i].a = pMesh->faces[i].v[0];
		pGeo->pFce[i].b = pMesh->faces[i].v[2];	// b <--> c ��ȯ
		pGeo->pFce[i].c = pMesh->faces[i].v[1];
	}

	// ���� ������ ����
	for (i=0; i<iNvtx; ++i)
	{
		Point3 v = pMesh->verts[i];
		pGeo->pPos[i].x = v.x;
		pGeo->pPos[i].y = v.z;	//y <--> z ��ȯ
		pGeo->pPos[i].z = v.y;
	}
}



void LcMax::SetupAnimation(LcGeo* pGeo)
{
	INT i;

	if(LCX_BONE != pGeo->nType)
		return;


	DWORD	dTick	= m_Header.nFrmT;
	DWORD	dTimeB	= m_Header.nFrmB * dTick;
	DWORD	dTimeE	= m_Header.nFrmE * dTick;

	INT		nAni	=0;
	DWORD	dTime	=0;

	// Total Animation
	nAni = m_Header.nFrmE - m_Header.nFrmB +1;


	INode*	pNode = pGeo->pNode;
	INode*	pPrnt = pNode->GetParentNode();

	pGeo->nAni	= nAni;
	pGeo->pAni	= new MATA[nAni];

	dTime = dTimeB;
	i	= 0;
	for(; dTime<=dTimeE ; dTime += dTick, ++i)
	{
		MATA* pDest = &pGeo->pAni[i];

		Matrix3 tmLocal;
		Matrix3 tmWorld = pNode->GetObjTMAfterWSM(dTime);

		if(!pPrnt)
			tmLocal = tmWorld;
		else
		{
			Matrix3 tmParent= pPrnt->GetObjTMAfterWSM(dTime);
			tmLocal = tmWorld * Inverse(tmParent);
		}

		MaxMatrixToD3D(pDest, &tmLocal);
	}
}



INT LcMax::FindBoneId(INode* pNode)
{
	for(int i=0; i<m_Header.nGeo; ++i)
	{
		LcGeo*	pGeo	= &m_pGeo[i];
		if(pGeo->pNode == pNode)
			return i;
	}

	return -1;
}


// Save Binary File
void LcMax::WriteBinary()
{
	INT n;

	FILE*	fp = fopen(m_sFb, "wb");

	fwrite(&m_Header, 1, sizeof(LcHeader), fp);
	fseek(fp, LCX_HDEADER_OFFSET, SEEK_SET);

	// Write Geometry
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fwrite(pGeo->sName,  1, sizeof(char)*32, fp);	// Node Name
		fwrite(&pGeo->nType, 1, sizeof(INT ), fp);		// Node Type
		fwrite(&pGeo->nFce,  1, sizeof(INT ), fp);		// Index Number
		fwrite(&pGeo->nPos,  1, sizeof(INT ), fp);		// Vertex Number

		fwrite(&pGeo->nPrn,  1, sizeof(INT ), fp);		// Parent Index
		fwrite(&pGeo->mtLcl, 1, sizeof(MATA), fp);		// Local Matrix
		fwrite(&pGeo->nAni,  1, sizeof(INT ), fp);		// Animation Number

		if(1 > pGeo->nFce || 1 > pGeo->nPos)
			continue;

		// Write Mesh
		fwrite(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);
		fwrite(pGeo->pPos, pGeo->nPos, sizeof(VtxPos), fp);
	}

	// Write Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(1>pGeo->nAni)
			continue;

		fwrite(pGeo->pAni, pGeo->nAni, sizeof(MATA), fp);	// Animation Matrix
	}

	fclose(fp);
}


// Save Text File
void LcMax::WriteText()
{
	INT n, i;

	FILE*	fp = fopen(m_sFt, "wt");

	fprintf(fp, "\nTotal_Node: %d\n", m_Header.nGeo);
	fprintf(fp, "Scene: %ld %ld %ld %ld\n"
			, m_Header.nFrmB
			, m_Header.nFrmE
			, m_Header.nFrmP
			, m_Header.nFrmT);

	fprintf(fp, "\n");

	// Write Mesh
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];
		INode* pPrn = pGeo->pNode->GetParentNode();

		fprintf(fp, "Node: %2d (\"%s\")"
					" Type: %d"
					" Parent: %d"
					, n
					, pGeo->sName
					, pGeo->nType
					, pGeo->nPrn
					);

		if(pPrn)
			fprintf(fp, " (\"%s\")\n", pPrn->GetName());
		else
			fprintf(fp, " (\"<NULL>\")\n");


		fprintf(fp, "IndexNumber:  %2d VertexNumber: %2d\n"
					, pGeo->nFce, pGeo->nPos);

		fprintf(fp, "AnimationNumber: %2d\n", pGeo->nAni);

		fprintf(fp, "LocalMatrix {\n");
		fprintf(fp, "	%10.5f %10.5f %10.5f %10.5f\n", pGeo->mtLcl._11, pGeo->mtLcl._12, pGeo->mtLcl._13, pGeo->mtLcl._14);
		fprintf(fp, "	%10.5f %10.5f %10.5f %10.5f\n", pGeo->mtLcl._21, pGeo->mtLcl._22, pGeo->mtLcl._23, pGeo->mtLcl._24);
		fprintf(fp, "	%10.5f %10.5f %10.5f %10.5f\n", pGeo->mtLcl._31, pGeo->mtLcl._32, pGeo->mtLcl._33, pGeo->mtLcl._34);
		fprintf(fp, "	%10.5f %10.5f %10.5f %10.5f\n", pGeo->mtLcl._41, pGeo->mtLcl._42, pGeo->mtLcl._43, pGeo->mtLcl._44);
		fprintf(fp, "}\n");

		if(pGeo->nFce <1 || pGeo->nPos <1)
		{
			fprintf(fp, "\n");
			continue;
		}

		fprintf(fp, "Face {\n");

		for (i=0; i<pGeo->nFce; ++i)
		{
			INT a, b, c;
			a = pGeo->pFce[i].a;
			b = pGeo->pFce[i].b;
			c = pGeo->pFce[i].c;

			fprintf(fp, "	%4d		%4d %4d %4d\n", i, a, b, c);
		}


		fprintf(fp, "}\n");


		fprintf(fp, "Vertex {\n");

		for (i=0; i<pGeo->nPos; ++i)
		{
			FLOAT x = pGeo->pPos[i].x;
			FLOAT y = pGeo->pPos[i].y;
			FLOAT z = pGeo->pPos[i].z;

			fprintf(fp, "	%4d		%10.5f %10.5f %10.5f\n", i, x, y, z);
		}

		fprintf(fp, "}\n\n");
	}



	// Write Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];
		INode* pPrn = pGeo->pNode->GetParentNode();

		if(1>pGeo->nAni)
			continue;

		fprintf(fp, "Animation: %2d (\"%s\") {\n", n, pGeo->sName);

		for (i=0; i<pGeo->nAni; ++i)
		{
			MATA* pTM = &pGeo->pAni[i];
			fprintf(fp, "	%2d ", i);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_11, pTM->_12, pTM->_13, pTM->_14);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_21, pTM->_22, pTM->_23, pTM->_24);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_31, pTM->_32, pTM->_33, pTM->_34);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_41, pTM->_42, pTM->_43, pTM->_44);
			fprintf(fp, "\n");
		}

		fprintf(fp, "}\n\n");
	}

	fprintf(fp, "\n");

	fclose(fp);
}


