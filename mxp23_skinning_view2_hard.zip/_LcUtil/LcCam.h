// Interface for the CLcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _LcCam_H_
#define _LcCam_H_

class CLcCam
{
protected:
	PDEV		m_pDev;

	FLOAT		m_fFv;															// Field of View
    FLOAT		m_fAs;															// Aspect Ratio
    FLOAT		m_fNr;															// Near
    FLOAT		m_fFr;															// Far

	VEC3		m_vcEye;														// Camera position
	VEC3		m_vcLook;														// Look vector
	VEC3		m_vcUp;															// up vector

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	MATA		m_mtViw;														// View Matrix
	MATA		m_mtPrj;														// Projection Matrix
	
public:
	CLcCam();
	virtual ~CLcCam();

	INT		Create(PDEV pDev);
	INT		FrameMove();

	MATA	GetMatrixViw()		{	return m_mtViw;		}
	MATA	GetMatrixPrj()		{	return m_mtPrj;		}

	VEC3	GetCamPos()			{	return m_vcEye;		}
	VEC3	GetCamLook()		{	return m_vcLook;	}
	VEC3	GetCamUp()			{	return m_vcUp;		}

public:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	void	Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed);
};

#endif
