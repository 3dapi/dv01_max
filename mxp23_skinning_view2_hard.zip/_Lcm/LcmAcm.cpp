// Implementation of the CLcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"
#include "LcmAcm.h"


#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] (p);	(p) = NULL;	} }
#define SAFE_RELEASE(p)		{ if(p){ (p)->Release(); (p) = NULL;} }







CLcmAcm::CLcmAcm()
{
	m_pDev	= NULL;
	m_pGeo	= NULL;

	m_nAni	= 0;
}


CLcmAcm::~CLcmAcm()
{
	Destroy();
}


void CLcmAcm::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pGeo	);
}


INT CLcmAcm::Create(void* p1, void* p2, void* p3, void* p4)
{
	INT i;

	m_pDev	= (PDEV)p1;

	if(FAILED( LoadMdl((char*)p2)))
		return -1;


	D3DXMATRIX mtS;
	D3DXMATRIX mtR;
	D3DXMATRIX mtT;

	D3DXMatrixIdentity(&mtS);
	D3DXMatrixIdentity(&mtR);
	D3DXMatrixIdentity(&mtT);

	D3DXMatrixScaling(&mtS, 3,3,3);
	D3DXMatrixRotationY(&mtR, D3DXToRadian(-30));
	D3DXMatrixTranslation(&mtT, 50, 0, 30);

	m_mtWld = mtS * mtR * mtT;



	for(i=0; i<LCM_MAX_BLEND; ++i)
		D3DXMatrixIdentity(&m_mtBlnd[i]);

	m_TimeB = GetTickCount();

	return 0;
}


INT CLcmAcm::FrameMove()
{
	INT n;

	m_TimeC = GetTickCount();

	DWORD dTime = m_TimeC - m_TimeB;

	m_nAni = INT( dTime/m_Header.nFrmP);

	m_nAni %= m_Header.nFrmE;

	for(n=0; n<m_Header.nGeo; ++n)						// World ��� ������Ʈ
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		MATA	mtAni;
		D3DXMatrixIdentity(&mtAni);

		if(pGeo->pAni)
			mtAni = pGeo->pAni[m_nAni];

		m_mtBlnd[n] =  mtAni * m_mtWld;
	}

	return 0;
}

void CLcmAcm::Render()
{
	static	MATA mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

	INT	n =0;
	INT	k =0;

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	m_pDev->SetTexture(0, NULL);

	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];

		if(pGeo->nFce <1 || pGeo->nVtx <1 )
			continue;


		// Bone�� ���
		if(pGeo->nType == LCX_BONE)
		{
			m_pDev->SetTransform(D3DTS_WORLD, &m_mtBlnd[n]);
			continue;
		}

		// �޽��� ���
		else if(pGeo->nType == LCX_MESH)
		{
			m_pDev->SetSoftwareVertexProcessing(TRUE);
			m_pDev->SetRenderState(D3DRS_INDEXEDVERTEXBLENDENABLE, TRUE );
			m_pDev->SetRenderState(D3DRS_VERTEXBLEND, D3DVBF_3WEIGHTS );

			for(k=0; k<LCM_MAX_BLEND; ++k)
				m_pDev->SetTransform( D3DTS_WORLDMATRIX(k), &m_mtBlnd[k] );
		}
		
		m_pDev->SetFVF(pGeo->dFVF);
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
											, 0, pGeo->nVtx
											, pGeo->nFce
											, pGeo->pFce
											, (D3DFORMAT)VtxIdx::FVF
											, pGeo->pVtx
											, pGeo->dVtx
											);


		if(VtxBlend::FVF == pGeo->dFVF)
		{
			m_pDev->SetRenderState( D3DRS_INDEXEDVERTEXBLENDENABLE, FALSE);
			m_pDev->SetRenderState( D3DRS_VERTEXBLEND, D3DVBF_DISABLE  );
			m_pDev->SetSoftwareVertexProcessing(FALSE);

			for(k=0; k<LCM_MAX_BLEND; ++k)
				m_pDev->SetTransform( D3DTS_WORLDMATRIX(k), &mtI);
		}
	}

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);	// ���� ��� ����
}
	

INT CLcmAcm::LoadMdl(char* sFile)
{
	INT		n=0;
	INT		j=0;
	INT		k=0;

	FILE*	fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;


	fread(&m_Header, 1, sizeof(LcHeader), fp);

	if(m_Header.nGeo<1)
		return 0;


	fseek(fp, LCX_HDEADER_OFFSET, SEEK_SET);

	m_pGeo = new LcGeo[m_Header.nGeo];


	// Read Mesh
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fread(pGeo->sName ,32, sizeof(char), fp);	// Node Name
		fread(&pGeo->nType, 1, sizeof(INT ), fp);	// Node Type
		fread(&pGeo->nPrn , 1, sizeof(INT ), fp);	// Parent Index

		fread(&pGeo->nFce , 1, sizeof(INT ), fp);	// Index Number
		fread(&pGeo->nVtx , 1, sizeof(INT ), fp);	// Vertex Number
		fread(&pGeo->nAni , 1, sizeof(INT ), fp);	// Animation Number


		// �θ� ��� ����
		if(-1 != pGeo->nPrn)
			pGeo->pPrn = &m_pGeo[pGeo->nPrn];

		if(1 > pGeo->nFce || 1 > pGeo->nVtx)
			continue;


		if(LCX_BONE == pGeo->nType)
		{
			pGeo->dFVF = VtxPos::FVF;
			pGeo->dVtx = sizeof(VtxPos);
		}
		else if(LCX_MESH == pGeo->nType)
		{
			pGeo->dFVF = VtxBlend::FVF;
			pGeo->dVtx = sizeof(VtxBlend);
		}
		else
		{
			pGeo->nFce = 0;
			pGeo->nVtx = 0;
			continue;
		}


		pGeo->pFce = new VtxIdx[pGeo->nFce];
		fread(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);



		pGeo->pVtx = malloc(pGeo->dVtx * pGeo->nVtx);

		if(LCX_BONE == pGeo->nType)
			fread(pGeo->pVtx, pGeo->dVtx, pGeo->nVtx, fp);
		else if(LCX_MESH == pGeo->nType)
		{
			VtxBlend* pVtx = (VtxBlend*)pGeo->pVtx;

			for(j=0; j<pGeo->nVtx; ++j)
				fread(&pVtx[j], sizeof(VtxPos), 1, fp);
		}
	}


	// Read Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(1>pGeo->nAni)
			continue;

		pGeo->pAni = new MATA[pGeo->nAni];
		fread(pGeo->pAni, pGeo->nAni, sizeof(MATA), fp);	// Animation Matrix
	}


	// Reading Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		fread(&pGeo->nBlnd, sizeof(INT ), 1, fp);

		if(0>=pGeo->nBlnd)
			continue;

		pGeo->pBlnd = new LcmBone[pGeo->nVtx];

		for(j=0; j<pGeo->nVtx; ++j)
		{
			LcmBone*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = 0;

			fread(&iBone, sizeof(INT ), 1, fp);

			for(k=0; k<iBone; ++k)
			{
				INT		nB = -1;
				FLOAT	fW = 0.f;
				fread(&nB, sizeof(INT  ), 1, fp);
				fread(&fW, sizeof(FLOAT), 1, fp);

				pBlnd->vB.push_back(Tbone(nB, fW));
			}
		}
	}

	fclose(fp);



	// Copy Vertex Weight data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(0>=pGeo->nBlnd)
			continue;

		VtxBlend*	pVtx = (VtxBlend*)pGeo->pVtx;

		for(j=0; j<pGeo->nVtx; ++j)
		{
			// Blend ����
			LcmBone*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = pBlnd->vB.size();

			FLOAT		g[16]={0};		// BLEND WEIGHT
			BYTE		m[16]={0};		// MATRIX Index

			for(int k=0; k<iBone; ++k)
			{
				g[k] = pBlnd->vB[k].fW;
				m[k] = pBlnd->vB[k].nB;
			}

			pVtx[j].g[0] = g[0];
			pVtx[j].g[1] = g[1];
			pVtx[j].g[2] = g[2];

			pVtx[j].m[0] = m[0];
			pVtx[j].m[1] = m[1];
			pVtx[j].m[2] = m[2];
			pVtx[j].m[3] = m[3];
		}
	}


	// Delete Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		if(0>=pGeo->nBlnd)
			continue;

		delete [] pGeo->pBlnd;
		pGeo->pBlnd = NULL;
	}

	return 0;
}


