/**********************************************************************
 *<
	FILE: mymax.h

	DESCRIPTION:	Includes for Plugins

	CREATED BY:

	HISTORY:

 *>	Copyright (c) 2000, All Rights Reserved.
 **********************************************************************/

#ifndef __mymax__H
#define __mymax__H

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"



extern TCHAR *GetString(int id);

extern HINSTANCE hInstance;

#endif // __mymax__H
