// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#define SAFE_DELETE(p)		{ if(p){ delete  p; p = NULL;	}	}
#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] p; p = NULL;	}	}


#include "_StdAfx.h"


// Dummy for progressbar
DWORD WINAPI fn(LPVOID arg)
{
	return(0);
}


int	LcMax::DoExport(const TCHAR *sFile,ExpInterface *ei,Interface *pi, BOOL suppressPrompts, DWORD options)
{
	INT		n = 0;
	INT		i =0;

	HWND	hWndPrn = pi->GetMAXHWnd();// = GetActiveWindow();

	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_MAIN), hWndPrn, (DLGPROC)LcMaxOptionsDlgProc, (LPARAM)this);

	if(FALSE == m_bDoExport)
		return FALSE;


	m_pE	= ei;
	m_pI	= pi;
	m_bS	= suppressPrompts;
	m_dO	= options;


	// 0. Prepare: ���� �̸� ����
	memset(m_sFb, 0, sizeof m_sFb);	// Export Binary File Name
	memset(m_sFt, 0, sizeof m_sFt);	// Export Text File Name
	memset(m_sFl, 0, sizeof m_sFl);	// Export Log File Name
	strcpy(m_sFb, sFile);


	// �����̸� �ҹ��� ��ȯ
	char *s = (char*)sFile;
	char *e = (char*)sFile;
	char *d = (char*)m_sFb;

	e+= strlen( m_sFb );
	for( ; s<e; ++s, ++d)
		*d = tolower(*s);


	// 0. ���� �̸� ����
	FileRename(m_sFt, m_sFb, NULL, "act");
	FileRename(m_sFl, m_sFb, NULL, "acz");



	// 0. ����� ������ ������.
	int		 iTick = GetTicksPerFrame();
	Interval range = m_pI->GetAnimRange();

	m_Header.nFrmB = range.Start() / iTick;
	m_Header.nFrmE = range.End() / iTick;
	m_Header.nFrmP = GetFrameRate();			// FPS
	m_Header.nFrmT = iTick;



	// 1. Gather Node
	INode*	pRoot = m_pI->GetRootNode();
	GatherNode(pRoot);


	// 2. Create Geometry
	m_Header.nGeo = m_vMaxNode.size();
	if(m_Header.nGeo<1)
		return -1;


	m_pI->ProgressStart("Exporting Acm File...", TRUE, fn, NULL);
	m_pGeo = new LcGeo[m_Header.nGeo];

	
	// 3. Binding Bone to LcGeo
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		INode*	pNode = m_vMaxNode[n];
		pGeo->pNode	= pNode;

		TCHAR*	sName  = pNode->GetName();
		sprintf(pGeo->sName, sName);
	}


	m_pI->ProgressUpdate(2, TRUE, "Prepare");

	// 4. Bone or Not
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupIsBone(pGeo);
	}


	// 5. Setup Parent Index
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupParentIndex(pGeo);
	}


	// 6. Physique or Skinning�� �����Ѵ�.
	for(i=0; i<m_Header.nGeo; ++i)
	{
		LcGeo*	pGeo	= &m_pGeo[i];
		SetupBoneWeight(pGeo);
	}


	m_pI->ProgressUpdate(4, TRUE, "Setup Mesh");

	// 7. Setup Geometry
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		SetupGeometry(pGeo);
	}


	
	// 8. Setup Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		m_pI->ProgressUpdate(6 + int(float(n*92)/m_Header.nGeo), TRUE, "Setup Animation");

		LcGeo*	pGeo = &m_pGeo[n];
		SetupAnimation(pGeo);
	}


	m_pI->ProgressUpdate(99, TRUE, "Write Files");

	// 9. ���� ���
	WriteBinary();
	WriteText();


	SAFE_DELETE_ARRAY(	m_pGeo	);
	m_bDoExport = FALSE;


	m_pI->ProgressEnd();

	return TRUE;
}


void LcMax::GatherNode(INode* pNode)
{
	if(!pNode)
		return;

	m_vMaxNode.push_back(pNode);

	INT iChild = pNode->NumberOfChildren();

	for(int i=0; i<iChild; ++i)
	{
		INode* pChild = pNode->GetChildNode(i);

		if(pChild)
			GatherNode(pChild);
	}
}



void LcMax::SetupIsBone(LcGeo* pGeo)
{
	INode*	pNode = pGeo->pNode;

	if(NULL == pNode)
		return ;


	ObjectState os = pNode->EvalWorldState(0);

	if (!os.obj)
		return;

	if( 0 == _strnicmp(pNode->GetName(), "Bone", 4) ||
		0 == _strnicmp(pNode->GetName(), "Bip", 3))
	{
		pGeo->nType = LCX_BONE;
		return;
	}

	if(	os.obj->ClassID() == Class_ID(BONE_CLASS_ID, 0) ||
		os.obj->ClassID() == BONE_OBJ_CLASSID ||
		os.obj->ClassID() == Class_ID(DUMMY_CLASS_ID, 0) )
	{
		pGeo->nType = LCX_BONE;
		return;
	}


	Control *cont = pNode->GetTMController();
	if(cont->ClassID() == BIPSLAVE_CONTROL_CLASS_ID ||		//others biped parts
		cont->ClassID() == BIPBODY_CONTROL_CLASS_ID	||		//biped root "Bip01"
		cont->ClassID() == FOOTPRINT_CLASS_ID				//Bip01 Footsteps
		)
		pGeo->nType = LCX_BONE;
}


void LcMax::SetupParentIndex(LcGeo* pGeo)
{
	INode*	pNode = pGeo->pNode;
	INode*	pPrn = pNode->GetParentNode();

	if(pPrn)
		pGeo->nPrn = FindBoneId(pPrn);
}


void LcMax::SetupGeometry(LcGeo* pGeo)
{
	INT		n;

	INode*	pNode = pGeo->pNode;
	TCHAR*	sName = pNode->GetName();

	Object* pObj = pNode->EvalWorldState(0).obj;

	if(!pObj)
		return;

	SClass_ID lSuperID = pObj->SuperClassID();
	Class_ID lClassID = pObj->ClassID();


	if(GEOMOBJECT_CLASS_ID != lSuperID)
		return;

	// �޽��� �ﰢ������ �ٲ� �� �ִ°�?
//	if(!pObj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
//		return;

	// �ﰢ������ �޽��� �ٲ۴�.
	TriObject* pTri = (TriObject *)pObj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
	if(NULL == pTri)
		return;

	// �޽� ��ü�� ��´�.
	Mesh* pMesh	= &pTri->GetMesh();
	if(NULL ==pMesh)
		return;


	// �ε����� ������ ���ڸ� ��´�.
	INT	iNfce	= pMesh->getNumFaces();
	INT	iNvtx	= pMesh->getNumVerts();

	// Setup Index and Vertex Number
	pGeo->nFce = iNfce;
	pGeo->nVtx = iNvtx;

	// �ε����� ������ ������ ���� ������.
	if(iNfce <=0 || iNvtx <=0)
		return;


	// Setup Type
	if(LCX_BONE != pGeo->nType)
		pGeo->nType = LCX_MESH;



//	Matrix3	tmWSM = pNode->GetObjectTM(0);
	Matrix3	tmWSM = pNode->GetObjTMAfterWSM(0); // Skinning�� ���ؼ� �̰��� �ʿ�

	// Index Vertex ����
	pGeo->pFce = new VtxIdx[iNfce];
	pGeo->pPos = new VtxPos[iNvtx];

	// �ε��� ������ ����
	for (n=0; n<iNfce; ++n)
	{
		pGeo->pFce[n].a = pMesh->faces[n].v[0];
		pGeo->pFce[n].b = pMesh->faces[n].v[2];	// b <--> c ��ȯ
		pGeo->pFce[n].c = pMesh->faces[n].v[1];
	}

	// ���� ������ ����
	for (n=0; n<iNvtx; ++n)
	{
		Point3 v = tmWSM * pMesh->verts[n];	// ��ȯ�� ������ ����Ѵ�.
		
		pGeo->pPos[n].x = v.x;
		pGeo->pPos[n].y = v.z;	//y <--> z ��ȯ
		pGeo->pPos[n].z = v.y;
	}
}



void LcMax::SetupAnimation(LcGeo* pGeo)
{
	INT n;

	if(LCX_BONE != pGeo->nType)
		return;


	DWORD	dTick	= m_Header.nFrmT;
	DWORD	dTimeB	= m_Header.nFrmB * dTick;
	DWORD	dTimeE	= m_Header.nFrmE * dTick;

	INT		nAni	=0;
	DWORD	dTime	=0;

	// Total Animation
	nAni = m_Header.nFrmE - m_Header.nFrmB +1;


	INode*	pNode = pGeo->pNode;
	pGeo->nAni	= nAni;
	pGeo->pAni	= new MATA[nAni];

	MATA	mtPivot;
	Matrix3	tmPivot	= pNode->GetNodeTM(0);
	tmPivot.Invert();
	MaxMatrixToD3D(&mtPivot, &tmPivot);

	for(n=0, dTime = dTimeB; dTime<=dTimeE ; dTime += dTick, ++n)
	{
		MATA* pDest = &pGeo->pAni[n];

		Matrix3 tmWorld = pNode->GetObjTMAfterWSM(dTime);
		tmWorld.NoScale();

		MATA	mtAni;
		MaxMatrixToD3D(&mtAni, &tmWorld);
		mtAni  = mtPivot * mtAni;

		*pDest = mtAni;
	}
}



INT LcMax::FindBoneId(INode* pNode)
{
	for(int n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];
		if(pGeo->pNode == pNode)
			return n;
	}

	return -1;
}




void LcMax::SetupBoneWeight(LcGeo* pGeo)
{
	INode*		pNode = pGeo->pNode;			// Current Node
	Modifier*	pMod = NULL;

	// Physique ����
	pMod = (Modifier*)FindModifier(pNode, PHYSQ_CLASSID);

	if(pMod)
	{
		SetupPhysiqueWeight(pGeo, pMod);
		return;
	}

	// Skin ����
	pMod = (Modifier*)FindModifier(pNode, SKIN_CLASSID);

	if(pMod)
		SetupSkinWeight(pGeo, pMod);
}



void LcMax::SetupPhysiqueWeight(LcGeo* pGeo, Modifier* pMod)
{
	INode*				pNode = pGeo->pNode;			// Current Node
	IPhysiqueExport*	pExport = NULL;
	IPhyContextExport*	pContext = NULL;


	pExport = (IPhysiqueExport*)pMod->GetInterface(I_PHYINTERFACE);		// Physique�� ��ü
	if(!pExport)
		return;

	
	pContext = (IPhyContextExport*)pExport->GetContextInterface(pNode);	// Physique Export�� ���� Context�� ���Ѵ�.
	if(!pContext)
	{
		pMod->ReleaseInterface(I_PHYINTERFACE, pExport);
		return;
	}

	pContext->ConvertToRigid(TRUE);					// Context�� ���ؼ� ��� ������ Rigid�� �ٲ۴�.
	pContext->AllowBlending(TRUE);					// Blending Ȱ��ȭ

	int nVtx = pContext->GetNumberVertices();		// Bone�� ����޴� ������ ����

	if(nVtx <=0)
		return;

	
	pGeo->nBlnd = nVtx;
	pGeo->pBlnd = new LcmBoneS[nVtx];

	
	for(int j=0; j<nVtx; ++j)
	{
		//get i-th vertex
		IPhyVertexExport*		pPhyVtxExpt = (IPhyVertexExport*)pContext->GetVertexInterface(j);
		IPhyBlendedRigidVertex* pPhyBlend	= (IPhyBlendedRigidVertex*)pPhyVtxExpt;

		if(!pPhyVtxExpt)
			continue;


		if(RIGID_TYPE == pPhyVtxExpt->GetVertexType())
		{
			//�� �ε����� ���Ѵ�.
			INode*	pBone	= ((IPhyRigidVertex*)pPhyVtxExpt)->GetNode();
			INT		nBone	= FindBoneId(pBone);
			FLOAT	fWgt	= 1.f;		//RIGID_TYPE�� Weight=1 �̴�.

			
			pGeo->pBlnd[j].vB.insert(std::pair<INT, FLOAT>(nBone, fWgt));
			continue;
		}
		

		int numBones = pPhyBlend->GetNumberNodes();
		for(int k = 0; k< numBones; ++k)
		{
			// k��°�� ���� ã�´�.
			INode*	pBone	= pPhyBlend->GetNode(k);
			INT		nBone	= FindBoneId(pBone);
			FLOAT	fWgt	= pPhyBlend->GetWeight(k);
			

			// ���� ������ ����
			if(fWgt<0.00005f)
				continue;


			pGeo->pBlnd[j].vB.insert(std::pair<INT, FLOAT>(nBone, fWgt));
		}
	}


	pExport->ReleaseContextInterface(pContext);
	pMod->ReleaseInterface(I_PHYINTERFACE, pExport);
}





void LcMax::SetupSkinWeight(LcGeo* pGeo, Modifier* pMod)
{
	INode*				pNode = pGeo->pNode;			// Current Node
	ISkin*				pExport = NULL;
	ISkinContextData*	pContext = NULL;


	pExport = (ISkin*)pMod->GetInterface(I_SKIN);		// Skin ��ü
	if(!pExport)
		return;

	pContext = pExport->GetContextInterface(pNode);		// SKin Export�� ���� Context�� ���Ѵ�.
	if(!pContext)
		return;

	int nVtx = pContext->GetNumPoints();				// Bone�� ����޴� ������ ����

	if(nVtx <=0)
		return;

	pGeo->nBlnd = nVtx;
	pGeo->pBlnd = new LcmBoneS[nVtx];


	for(int j=0; j<nVtx;  ++j)
	{
		int numBones = pContext->GetNumAssignedBones(j);
		
		for(int k=0; k<numBones; ++k)
		{
			int assignedBone = pContext->GetAssignedBone(j, k);

			if(assignedBone < 0)
				continue;

			INode*	pBone	= pExport->GetBone(assignedBone);
			INT		nBone	= FindBoneId(pBone);
			FLOAT	fWgt	= pContext->GetBoneWeight(j, k);

			// ���� ������ ����
			if(fWgt<0.00005f)
				continue;

			pGeo->pBlnd[j].vB.insert(std::pair<INT, FLOAT>(nBone, fWgt));
		}
	}

	pMod->ReleaseInterface(I_SKIN, pExport);
}



void* LcMax::FindModifier(INode *pNode, Class_ID nType)
{
	// ��忡 ����� ������Ʈ�� ���Ѵ�.
	Object* ObjectPtr = pNode->GetObjectRef();

	if(!ObjectPtr)
		return NULL;

	// Derived ������Ʈ��� �� ������Ʈ���� �����ڸ� ã�´�.
	while(ObjectPtr && ObjectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		IDerivedObject *pDerivedObj = (IDerivedObject *)ObjectPtr;


		// ������ ������ ���� Ž���Ѵ�.
		int ModStackIndex = 0;
		while(ModStackIndex < pDerivedObj->NumModifiers())
		{
			// ���� �ε����� ���� �����ڸ� ��´�.
			Modifier* ModifierPtr = pDerivedObj->GetModifier(ModStackIndex);

			//�� �������� ���̵� PHYSIQUE �Ǵ� SKIN���� ���Ѵ�.
			if(nType == ModifierPtr->ClassID())
				return ModifierPtr;

			
			// �����ڰ� PHYSIQUE �Ǵ� SKIN�� �ƴϸ� �ε����� �ø���.
			ModStackIndex++;
		}

		// Derived ������Ʈ�� ����� �ٸ� ������Ʈ�� ��´�.
		ObjectPtr = pDerivedObj->GetObjRef();
	}

	// �߰� ����.
	return NULL;
}









// Save Binary File
void LcMax::WriteBinary()
{
	INT n;
	INT	j;

	FILE*	fp = fopen(m_sFb, "wb");

	fwrite(&m_Header, 1, sizeof(LcHeader), fp);
	fseek(fp, LCX_HDEADER_OFFSET, SEEK_SET);

	// Write Geometry
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fwrite(pGeo->sName ,32, sizeof(char), fp);	// Node Name
		fwrite(&pGeo->nType, 1, sizeof(INT ), fp);	// Node Type
		fwrite(&pGeo->nPrn , 1, sizeof(INT ), fp);	// Parent Index

		fwrite(&pGeo->nFce , 1, sizeof(INT ), fp);	// Index Number
		fwrite(&pGeo->nVtx , 1, sizeof(INT ), fp);	// Vertex Number
		fwrite(&pGeo->nAni , 1, sizeof(INT ), fp);	// Animation Number


		if(1 > pGeo->nFce || 1 > pGeo->nVtx)
			continue;

		// Write Mesh
		fwrite(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);
		fwrite(pGeo->pPos, pGeo->nVtx, sizeof(VtxPos), fp);
	}

	// Write Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(1>pGeo->nAni)
			continue;

		fwrite(pGeo->pAni, pGeo->nAni, sizeof(MATA), fp);	// Animation Matrix
	}



	// Export Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		fwrite(&pGeo->nBlnd, sizeof(INT ), 1, fp);

		if(0>=pGeo->nBlnd)
			continue;

		for(j=0; j<pGeo->nVtx; ++j)
		{
			LcmBoneS*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = pBlnd->vB.size();

			fwrite(&iBone, sizeof(INT ), 1, fp);

			std::map<INT, FLOAT >::iterator	__F = pBlnd->vB.begin();
			std::map<INT, FLOAT >::iterator	__L = pBlnd->vB.end();

			for(; __F != __L; ++__F)
			{
				INT		nB = (*__F).first;
				FLOAT	fW = (*__F).second;
				fwrite(&nB, sizeof(INT  ), 1, fp);
				fwrite(&fW, sizeof(FLOAT), 1, fp);
			}

		}
	}

	fclose(fp);
}


// Save Text File
void LcMax::WriteText()
{
	INT n, j;

	FILE*	fp = fopen(m_sFt, "wt");

	fprintf(fp, "\nTotal_Node: %d\n", m_Header.nGeo);
	fprintf(fp, "Scene: %ld %ld %ld %ld\n"
			, m_Header.nFrmB
			, m_Header.nFrmE
			, m_Header.nFrmP
			, m_Header.nFrmT);

	fprintf(fp, "\n");

	// Write Mesh
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];
		INode* pPrn = pGeo->pNode->GetParentNode();

		fprintf(fp, "Node: %2d (\"%s\")"
					" Type: %d"
					" Parent: %d"
					, n
					, pGeo->sName
					, pGeo->nType
					, pGeo->nPrn
					);

		if(pPrn)
			fprintf(fp, " (\"%s\")\n", pPrn->GetName());
		else
			fprintf(fp, " (\"<NULL>\")\n");


		fprintf(fp, "IndexNumber:  %2d VertexNumber: %2d\n"
					, pGeo->nFce, pGeo->nVtx);

		fprintf(fp, "AnimationNumber: %2d\n", pGeo->nAni);


		if(pGeo->nFce <1 || pGeo->nVtx <1)
		{
			fprintf(fp, "\n");
			continue;
		}

		fprintf(fp, "Face {\n");

		for (j=0; j<pGeo->nFce; ++j)
		{
			INT a, b, c;
			a = pGeo->pFce[j].a;
			b = pGeo->pFce[j].b;
			c = pGeo->pFce[j].c;

			fprintf(fp, "	%4d		%4d %4d %4d\n", j, a, b, c);
		}


		fprintf(fp, "}\n");


		fprintf(fp, "Vertex {\n");

		for (j=0; j<pGeo->nVtx; ++j)
		{
			FLOAT x = pGeo->pPos[j].x;
			FLOAT y = pGeo->pPos[j].y;
			FLOAT z = pGeo->pPos[j].z;

			fprintf(fp, "	%4d		%10.5f %10.5f %10.5f\n", j, x, y, z);
		}

		fprintf(fp, "}\n\n");
	}



	// Write Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];
		INode* pPrn = pGeo->pNode->GetParentNode();

		if(1>pGeo->nAni)
			continue;

		fprintf(fp, "Animation: %2d (\"%s\") {\n", n, pGeo->sName);

		for (j=0; j<pGeo->nAni; ++j)
		{
			MATA* pTM = &pGeo->pAni[j];
			fprintf(fp, "	%2d ", j);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_11, pTM->_12, pTM->_13, pTM->_14);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_21, pTM->_22, pTM->_23, pTM->_24);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_31, pTM->_32, pTM->_33, pTM->_34);
			fprintf(fp, " %9.5f %9.5f %9.5f %9.5f", pTM->_41, pTM->_42, pTM->_43, pTM->_44);
			fprintf(fp, "\n");
		}

		fprintf(fp, "}\n\n");
	}


	// Export Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];

		if(!pGeo->pBlnd)
			continue;

		fprintf(fp, "Blend: %2d (\"%s\") {\n", n, pGeo->sName);

		for(j=0; j<pGeo->nVtx; ++j)
		{
			LcmBoneS*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = pBlnd->vB.size();

			fprintf(fp, "	%4d %2d : ", j, iBone);


			std::map<INT, FLOAT >::iterator	__F = pBlnd->vB.begin();
			std::map<INT, FLOAT >::iterator	__L = pBlnd->vB.end();

			for(; __F != __L; ++__F)
			{
				INT		nB = (*__F).first;
				FLOAT	fW = (*__F).second;
				fprintf(fp, "[%4d %7.6f]", nB, fW);
			}

			fprintf(fp, "\n");
		}

		fprintf(fp, "}\n\n");
	}

	fprintf(fp, "\n");

	fclose(fp);
}


