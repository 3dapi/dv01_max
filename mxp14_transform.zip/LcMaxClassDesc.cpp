// Implementation of the LcMaxClassDesc class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


int 			LcMaxClassDesc::IsPublic()		{ return TRUE; }
void *			LcMaxClassDesc::Create(BOOL)	{ return new LcMax(); }
const TCHAR *	LcMaxClassDesc::ClassName()		{ return GetString(IDS_CLASS_NAME); }
SClass_ID		LcMaxClassDesc::SuperClassID()	{ return SCENE_EXPORT_CLASS_ID; }
Class_ID		LcMaxClassDesc::ClassID()		{ return LCMAX_CLASS_ID; }
const TCHAR* 	LcMaxClassDesc::Category()		{ return GetString(IDS_CATEGORY); }
	
const TCHAR*	LcMaxClassDesc::InternalName()	{ return _T("LcMax"); }	
HINSTANCE		LcMaxClassDesc::HInstance()		{ return g_hInst; }
	
