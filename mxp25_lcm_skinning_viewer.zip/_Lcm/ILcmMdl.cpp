// Implementation of the ILcmMdl class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"
#include "LcmAcm.h"


INT LcMdl_Create(char* sCmd
				 , ILcmMdl** pData
				 , void* p1			// Original Source: Original Source�� NULL�̸� ���� ����
				 , void* p2			// Model File Name
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{

	(*pData) = NULL;

	if(0==_stricmp("Acm", sCmd))
	{
		CLcmAcm*	pObj = NULL;
		pObj = new CLcmAcm;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}

