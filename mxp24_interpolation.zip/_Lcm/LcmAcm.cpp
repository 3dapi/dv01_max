// Implementation of the CLcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"
#include "LcmAcm.h"


#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] (p);	(p) = NULL;	} }
#define SAFE_RELEASE(p)		{ if(p){ (p)->Release(); (p) = NULL;} }







CLcmAcm::CLcmAcm()
{
	m_pDev	= NULL;
	m_pGeo	= NULL;

	m_pFVF0	= NULL;
	m_pFVF1	= NULL;
	m_pEft	= NULL;

	m_TimeB	= 0;
	m_TimeC	= 0;
	m_nAni	= 0;
	m_bLinear	= FALSE;
}


CLcmAcm::~CLcmAcm()
{
	Destroy();
}


void CLcmAcm::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pGeo	);
	SAFE_RELEASE(		m_pFVF0	);
	SAFE_RELEASE(		m_pFVF1	);
}


INT CLcmAcm::Create(void* p1, void* p2, void* p3, void* p4)
{
	INT i;

	m_pDev	= (PDEV)p1;

	if(FAILED( LoadMdl((char*)p2)))
		return -1;


	D3DXMATRIX mtS;
	D3DXMATRIX mtR;
	D3DXMATRIX mtT;

	D3DXMatrixIdentity(&mtS);
	D3DXMatrixIdentity(&mtR);
	D3DXMatrixIdentity(&mtT);

	m_mtWld = mtS * mtR * mtT;


	for(i=0; i<LCM_MAX_BLEND; ++i)
		D3DXMatrixIdentity(&m_mtBlnd[i]);

	m_TimeB = GetTickCount();
	m_fAniSpd	= 1.f;

	return 0;
}


INT CLcmAcm::FrameMove()
{
	INT n;

	DOUBLE	dTimeC = GetTickCount();
	DOUBLE	fElapsed = dTimeC- m_TimeB;

	m_TimeB = dTimeC;
	m_TimeC += fElapsed * m_fAniSpd;
	
	FLOAT fAni	= m_TimeC/m_Header.nFrmP;
	FLOAT fWgt	= 0;

	m_nAni = INT( fAni);

	fWgt = fAni - m_nAni;
	m_nAni %= (m_Header.nFrmE-1);

	for(n=0; n<m_Header.nGeo; ++n)						// World ��� ������Ʈ
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		MATA	mtAni;
		D3DXMatrixIdentity(&mtAni);

		if(pGeo->pAni)
		{
			MatrixLerp(&mtAni, &pGeo->pAni[m_nAni], &pGeo->pAni[m_nAni+1], fWgt);
		}

		m_mtBlnd[n] =  mtAni;
	}

	return 0;
}

void CLcmAcm::Render()
{
	static	MATA mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

	INT		n =0;
	INT		k =0;
	INT		hr;

	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	m_pDev->SetSoftwareVertexProcessing(TRUE);
	m_pDev->SetTexture(0, NULL);


	D3DXMATRIX mtViw;
	D3DXMATRIX mtPrj;

	hr = m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	hr = m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);
	
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];

		if(pGeo->nFce <1 || pGeo->nVtx <1 )
			continue;



		hr = m_pEft->SetTechnique("Tech");

		hr = m_pEft->SetMatrix("m_mtViw", &mtViw);	// �� ��� ����
		hr = m_pEft->SetMatrix("m_mtPrj", &mtPrj);	// ���� ��� ����

		// Bone�� ���
		if(pGeo->nType == LCX_BONE)
		{
			continue;

			D3DXMATRIX mtWld = m_mtBlnd[n] * m_mtWld;
			hr = m_pEft->SetMatrix("m_mtWld", &mtWld);	// ���� ��� ����

			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(0);

				hr = m_pDev->SetVertexDeclaration(m_pFVF0);
				hr = m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
													, 0, pGeo->nVtx
													, pGeo->nFce
													, pGeo->pFce
													, (D3DFORMAT)VtxIdx::FVF
													, pGeo->pVtx
													, pGeo->dVtx
													);

			m_pEft->EndPass();
			m_pEft->End();

			
		}

		// �޽��� ���
		else if(pGeo->nType == LCX_MESH)
		{
				hr = m_pEft->SetMatrix("m_mtWld", &m_mtWld);		// ���� ��� ����
				hr = m_pEft->SetMatrixArray("m_mtBlnd", m_mtBlnd, LCM_MAX_BLEND);	// Blending ��� ����

			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(1);

				hr = m_pDev->SetVertexDeclaration(m_pFVF1);
				hr = m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
												, 0, pGeo->nVtx
												, pGeo->nFce
												, pGeo->pFce
												, (D3DFORMAT)VtxIdx::FVF
												, pGeo->pVtx
												, pGeo->dVtx
												);

			m_pEft->EndPass();
			m_pEft->End();

		}

		
	}

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	m_pDev->SetSoftwareVertexProcessing(FALSE);
}
	

INT CLcmAcm::LoadMdl(char* sFile)
{
	INT		n=0;
	INT		j=0;
	INT		k=0;

	FILE*	fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;


	fread(&m_Header, 1, sizeof(LcHeader), fp);

	if(m_Header.nGeo<1)
		return 0;


	fseek(fp, LCX_HDEADER_OFFSET, SEEK_SET);

	m_pGeo = new LcGeo[m_Header.nGeo];


	// Read Mesh
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fread(pGeo->sName ,32, sizeof(char), fp);	// Node Name
		fread(&pGeo->nType, 1, sizeof(INT ), fp);	// Node Type
		fread(&pGeo->nPrn , 1, sizeof(INT ), fp);	// Parent Index

		fread(&pGeo->nFce , 1, sizeof(INT ), fp);	// Index Number
		fread(&pGeo->nVtx , 1, sizeof(INT ), fp);	// Vertex Number
		fread(&pGeo->nAni , 1, sizeof(INT ), fp);	// Animation Number


		// �θ� ��� ����
		if(-1 != pGeo->nPrn)
			pGeo->pPrn = &m_pGeo[pGeo->nPrn];

		if(1 > pGeo->nFce || 1 > pGeo->nVtx)
			continue;


		if(LCX_BONE == pGeo->nType)
		{
			pGeo->dFVF = VtxPos::FVF;
			pGeo->dVtx = sizeof(VtxPos);
		}
		else if(LCX_MESH == pGeo->nType)
		{
			pGeo->dFVF = VtxBlend::FVF;
			pGeo->dVtx = sizeof(VtxBlend);
		}
		else
		{
			pGeo->nFce = 0;
			pGeo->nVtx = 0;
			continue;
		}


		pGeo->pFce = new VtxIdx[pGeo->nFce];
		fread(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);



		pGeo->pVtx = malloc(pGeo->dVtx * pGeo->nVtx);

		if(LCX_BONE == pGeo->nType)
			fread(pGeo->pVtx, pGeo->dVtx, pGeo->nVtx, fp);
		else if(LCX_MESH == pGeo->nType)
		{
			VtxBlend* pVtx = (VtxBlend*)pGeo->pVtx;

			for(j=0; j<pGeo->nVtx; ++j)
				fread(&pVtx[j], sizeof(VtxPos), 1, fp);
		}
	}


	// Read Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(1>pGeo->nAni)
			continue;

		pGeo->pAni = new MATA[pGeo->nAni];
		fread(pGeo->pAni, pGeo->nAni, sizeof(MATA), fp);	// Animation Matrix
	}


	// Reading Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		fread(&pGeo->nBlnd, sizeof(INT ), 1, fp);

		if(0>=pGeo->nBlnd)
			continue;

		pGeo->pBlnd = new LcmBone[pGeo->nVtx];

		for(j=0; j<pGeo->nVtx; ++j)
		{
			LcmBone*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = 0;

			fread(&iBone, sizeof(INT ), 1, fp);

			for(k=0; k<iBone; ++k)
			{
				INT		nB = -1;
				FLOAT	fW = 0.f;
				fread(&nB, sizeof(INT  ), 1, fp);
				fread(&fW, sizeof(FLOAT), 1, fp);

				pBlnd->vB.push_back(Tbone(nB, fW));
			}
		}
	}

	fclose(fp);



	// Copy Vertex Weight data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(0>=pGeo->nBlnd)
			continue;

		VtxBlend*	pVtx = (VtxBlend*)pGeo->pVtx;

		for(j=0; j<pGeo->nVtx; ++j)
		{
			// Blend ����
			LcmBone*	pBlnd = &pGeo->pBlnd[j];
			INT			iBone = pBlnd->vB.size();

			FLOAT		g[8]={0};		// BLEND WEIGHT
			BYTE		m[8]={0};		// MATRIX Index

			for(int k=0; k<iBone; ++k)
			{
				g[k] = pBlnd->vB[k].fW;
				m[k] = pBlnd->vB[k].nB;
			}

			pVtx[j].g[0] = g[0];
			pVtx[j].g[1] = g[1];
			pVtx[j].g[2] = g[2];

			pVtx[j].m[0] = m[0];
			pVtx[j].m[1] = m[1];
			pVtx[j].m[2] = m[2];
			pVtx[j].m[3] = m[3];
		}
	}


	// Delete Vertex Weight Data
	for(n=0; n<m_Header.nGeo; ++n)
	{
		LcGeo*	pGeo	= &m_pGeo[n];

		if(0>=pGeo->nBlnd)
			continue;

		delete [] pGeo->pBlnd;
		pGeo->pBlnd = NULL;
	}

	return 0;
}




void CLcmAcm::MatrixLerp(D3DXMATRIX* pOut, const D3DXMATRIX* m1, const D3DXMATRIX* m2, DOUBLE t)
{
	// �ִϸ��̼� ������ ���� ��
	if(m_bLinear)
	{
		*pOut = (1 - t) * (*m1) + t * (*m2);
	}

	// �ִϸ��̼� ������ ���� ��
	else
	{
		D3DXQUATERNION	q, q1, q2;
		D3DXVECTOR3	v, v1, v2;

		D3DXQuaternionRotationMatrix(&q1, m1);
		D3DXQuaternionRotationMatrix(&q2, m2);

		v1 = D3DXVECTOR3(m1->_41, m1->_42, m1->_43);
		v2 = D3DXVECTOR3(m2->_41, m2->_42, m2->_43);

		// ��ġ�� ���� ���� ����
		v = (1 - t) * v1 + t * v2;

		// ȸ���� ���� ����
		D3DXQuaternionSlerp(&q, &q1, &q2, t);

		// ȸ���� ��ķ� ��ȯ
		D3DXMatrixRotationQuaternion(pOut, &q);

		// ��ġ ����
		pOut->_41 = v.x;
		pOut->_42 = v.y;
		pOut->_43 = v.z;
	}
}



#define LCM_CMD_BEGIN(s1, s2)	if(0 == _stricmp(s1, s2)) {
#define LCM_CMD_END		return 0;	}


INT CLcmAcm::Query(char* sCmd, void* v)
{
	if(SUCCEEDED(CLcmMdl::Query(sCmd, v)))
		return 0;


	LCM_CMD_BEGIN(sCmd, "Set DXEffect")
		m_pEft = (PDEF)v;

		{
			D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
			D3DXDeclaratorFromFVF(VtxPos::FVF, vertex_decl);

			PDVD	pFVF=NULL;				// ��������
			
			if( FAILED(m_pDev->CreateVertexDeclaration(vertex_decl, &pFVF)))
				return -1;

			SAFE_RELEASE(	m_pFVF0	);
			m_pFVF0 = pFVF;
		}

		{
			D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
			D3DXDeclaratorFromFVF(VtxBlend::FVF, vertex_decl);

			PDVD	pFVF=NULL;				// ��������
			
			if( FAILED(m_pDev->CreateVertexDeclaration(vertex_decl, &pFVF)))
				return -1;

			SAFE_RELEASE(	m_pFVF1	);
			m_pFVF1 = pFVF;
		}
	LCM_CMD_END

	LCM_CMD_BEGIN(sCmd, "Set World Matrix")
		D3DXMATRIX* p = (D3DXMATRIX*)v;
		this->m_mtWld = *p;
	LCM_CMD_END

	LCM_CMD_BEGIN(sCmd, "Set Animation Speed")
		FLOAT* p = (FLOAT*)v;
		this->m_fAniSpd= *p;
	LCM_CMD_END

	LCM_CMD_BEGIN(sCmd, "Get Animation Speed")
		*((FLOAT*)v) = this->m_fAniSpd;
	LCM_CMD_END


	LCM_CMD_BEGIN(sCmd, "Set Interpolation Type")
		INT* p = (INT*)v;
		this->m_bLinear= *p;
	LCM_CMD_END

	LCM_CMD_BEGIN(sCmd, "Get Interpolation Type")
		*((INT*)v) = this->m_bLinear;
	LCM_CMD_END

	return -1;
}




