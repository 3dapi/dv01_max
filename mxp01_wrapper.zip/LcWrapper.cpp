/**********************************************************************
 *<
	FILE: LcWrapper.cpp

	DESCRIPTION:	Appwizard generated plugin

	CREATED BY:

	HISTORY:

 *>	Copyright (c) 2000, All Rights Reserved.
 **********************************************************************/

#include "LcWrapper.h"

#define LcWrapper_CLASS_ID	Class_ID(0x665c6a2f, 0x56e219b1)

class LcWrapper : public SceneExport
{
public:
	HINSTANCE		m_hInst;				// DLL Instance
	ClassDesc*		m_pChildDesc;			// DLL ���� ���� Child ��ü �ּ�
	SceneExport*	m_pChild;				// Export�� ��û�Ǵ� �۾��� ����� ��ü

public:
		static HWND hParams;

		int				ExtCount();					// Number of extensions supported
		const TCHAR *	Ext(int n);					// Extension #n (i.e. "3DS")
		const TCHAR *	LongDesc();					// Long ASCII description (i.e. "Autodesk 3D Studio File")
		const TCHAR *	ShortDesc();				// Short ASCII description (i.e. "3D Studio")
		const TCHAR *	AuthorName();				// ASCII Author name
		const TCHAR *	CopyrightMessage();			// ASCII Copyright message
		const TCHAR *	OtherMessage1();			// Other message #1
		const TCHAR *	OtherMessage2();			// Other message #2
		unsigned int	Version();					// Version number * 100 (i.e. v3.01 = 301)
		void			ShowAbout(HWND hWnd);		// Show DLL's "About..." box

		BOOL SupportsOptions(int ext, DWORD options);
		int				DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts=FALSE, DWORD options=0);



		//Constructor/Destructor

		LcWrapper();
		~LcWrapper();

};


class LcWrapperClassDesc:public ClassDesc2 {
	public:
	int 			IsPublic() { return TRUE; }
	void *			Create(BOOL loading = FALSE) { return new LcWrapper(); }
	const TCHAR *	ClassName() { return GetString(IDS_CLASS_NAME); }
	SClass_ID		SuperClassID() { return SCENE_EXPORT_CLASS_ID; }
	Class_ID		ClassID() { return LcWrapper_CLASS_ID; }
	const TCHAR* 	Category() { return GetString(IDS_CATEGORY); }

	const TCHAR*	InternalName() { return _T("LcWrapper"); }	// returns fixed parsable name (scripter-visible name)
	HINSTANCE		HInstance() { return hInstance; }				// returns owning module handle

};



static LcWrapperClassDesc LcWrapperDesc;
ClassDesc2* GetLcWrapperDesc() { return &LcWrapperDesc; }


BOOL CALLBACK LcWrapperOptionsDlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	static LcWrapper *imp = NULL;

	switch(message) {
		case WM_INITDIALOG:
			imp = (LcWrapper *)lParam;
			CenterWindow(hWnd,GetParent(hWnd));
			return TRUE;

		case WM_CLOSE:
			EndDialog(hWnd, 0);
			return TRUE;
	}
	return FALSE;
}


//--- LcWrapper -------------------------------------------------------
LcWrapper::LcWrapper()
{
	m_hInst		= NULL;
	m_pChildDesc= NULL;
	m_pChild	= NULL;

	// Load Plugin(DLL)
	m_hInst = LoadLibrary( "c:/asdexp.dle");

	if (!m_hInst)
	{
		MessageBox(NULL, "Load c:/asdexp.dle Failed", "Err", MB_ICONWARNING);
		m_hInst	= NULL;
		return;
	}

	// DLL���� �����ϴ� �Լ� �� Export�� ������ �� �ִ� ��ü �ּ� ��ȯ �Լ� ���
	typedef ClassDesc* (__stdcall *_LibClassDesc)(int i);

	//_LibClassDesc pLibClassDesc = (_LibClassDesc) GetProcAddress(m_hInst, (LPCSTR)3);
	_LibClassDesc pLibClassDesc = (_LibClassDesc) GetProcAddress(m_hInst, "LibClassDesc");

	if (pLibClassDesc)
	{
		m_pChildDesc = pLibClassDesc(0);

		// Export�� ����� ��ü ����
		m_pChild = (SceneExport*)m_pChildDesc->Create();
	}
}

LcWrapper::~LcWrapper()
{
	if(m_pChild)
	{
		delete m_pChild;
		m_pChild = NULL;
	}

	// Plugin ����
	if(m_hInst)
	{
		FreeLibrary(m_hInst);
		m_hInst = NULL;
	}
}

int LcWrapper::ExtCount()
{
	return 1;
}

const TCHAR *LcWrapper::Ext(int n)
{
	if(m_pChild)
		return m_pChild->Ext(n);

	return _T("Failed Ext");
}

const TCHAR *LcWrapper::LongDesc()
{
	static TCHAR s[1024];

	if(m_pChild)
		_stprintf(s, "Wrap(%s)", m_pChild->LongDesc());

	else
		_stprintf(s, _T("Failed to load Wrap"));

	return s;
}

const TCHAR *LcWrapper::ShortDesc()
{
	static TCHAR s[1024];

	if(m_pChild)
		_stprintf(s, "Wrap(%s)", m_pChild->ShortDesc());

	else
		_stprintf(s, _T("Failed to load Wrap"));

	return s;
}

const TCHAR *LcWrapper::AuthorName()
{
	if(m_pChild)
		return m_pChild->AuthorName();

	return _T("Failed AuthorName");
}

const TCHAR *LcWrapper::CopyrightMessage()
{
	if(m_pChild)
		return m_pChild->CopyrightMessage();

	return _T("Failed CopyrightMessage");
}

const TCHAR *LcWrapper::OtherMessage1()
{
	if(m_pChild)
		return m_pChild->OtherMessage1();

	return _T("Failed OtherMessage1");
}

const TCHAR *LcWrapper::OtherMessage2()
{
	if(m_pChild)
		return m_pChild->OtherMessage2();

	return _T("Failed OtherMessage2");
}

unsigned int LcWrapper::Version()
{
	//TODO: Return Version number * 100 (i.e. v3.01 = 301)
	return 100;
}

void LcWrapper::ShowAbout(HWND hWnd)
{
	// Optional
}

BOOL LcWrapper::SupportsOptions(int ext, DWORD options)
{
	// TODO Decide which options to support.  Simply return
	// true for each option supported by each Extension
	// the exporter supports.

	return TRUE;
}


int	LcWrapper::DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts, DWORD options)
{
	if(m_pChild)
		return m_pChild->DoExport(name, ei, i, suppressPrompts, options);

	return FALSE;
}


