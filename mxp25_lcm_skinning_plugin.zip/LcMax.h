// Interface for the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif


#ifndef _LcMax_H_
#define _LcMax_H_

#pragma warning(disable: 4530)
#pragma warning(disable: 4786)

#include <vector>
#include <set>
#include <map>
#include <string>

#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")


using namespace std;

#define LCMAX_CLASS_ID	Class_ID(0x4228b838, 0xe0b3452)





#define PHYSQ_CLASSID Class_ID(PHYSIQUE_CLASS_ID_A, PHYSIQUE_CLASS_ID_B)

#ifndef SKIN_CLASSID
#define SKIN_CLASSID Class_ID(9815843,87654)
#endif


typedef D3DXMATRIX		MATA;




struct VtxIdx
{
	WORD a, b, c;

	VtxIdx() : a(0), b(1), c(2){}
	VtxIdx(WORD A,WORD B,WORD C) : a(A), b(B), c(C){}
};


// Geometry Type
enum ELcGeo
{
	LCX_ETC		=0,
	LCX_MESH	=1,
	LCX_BONE	=2,

	LCX_HDEADER_OFFSET	= 64,
	LCM_TEX_NAME		= 128,
};


struct LcmBoneS
{
	std::map<INT, FLOAT >	vB;		// Bone Index
};


struct LcGeo
{
	char			sName[32];	// Node Name
	INT				nType;		// 1:Geometry, 2: Bone, 0: Etc

	INode*			pNode;		// Node
	INT				nPrn;		// Parent Index

	INT				nFce;		// Number of Face
	INT				nVtx;		// Number of Position
	
	VtxIdx*			pFce;		// Face List
	D3DXVECTOR3*	pPos;		// Position List
	D3DXVECTOR3*	pNor;		// Normal Vector
	D3DXVECTOR2*	pUVW;		// Texture Coordinate

	INT				nBlnd;		// Bone�� ����޴� ���ؽ� ��
	LcmBoneS*		pBlnd;		// Source

	INT				nAni;		// Number of Animation
	D3DXMATRIX*		pAni;		// Animation Matrix

	INT				nTex;		// Texture File Index

	LcGeo()
	{
		memset(sName, 0, sizeof sName);
		nType	= LCX_ETC;

		pNode	= NULL;
		nPrn	= -1;					// �θ� ����

		nFce	= 0;
		nVtx	= 0;
		pFce	= NULL;
		pPos	= NULL;
		pNor	= NULL;
		pUVW	= NULL;

		nBlnd	= 0;
		pBlnd	= NULL;
		nAni	= 0;
		pAni	= NULL;

		nTex	= -1;
	}

	~LcGeo()
	{
		if(pFce){	delete [] pFce; pFce = NULL;	}
		if(pPos){	delete [] pPos; pPos = NULL;	}
		if(pNor){	delete [] pNor; pNor = NULL;	}
		if(pUVW){	delete [] pUVW; pUVW = NULL;	}
		if(pAni){	delete [] pAni; pAni = NULL;	}
		if(pBlnd){	delete [] pBlnd; pBlnd = NULL;	}
	}
};


struct LcMtl
{
	INode*			pNode;		// Material Node
	Mtl*			pMtrl;		// Material

	LcMtl() : pNode(NULL), pMtrl(NULL){}
	LcMtl(INode* n, Mtl* m) : pNode(n), pMtrl(m){}
};


struct LcTex
{
	INode*			pNode;		// Material Node
	Mtl*			pMtrl;		// Material
	std::string		sTex;

	INT				nTex;		// Teture File Index

	LcTex() : pNode(NULL), pMtrl(NULL), nTex(-1){}
	LcTex(INode* n, Mtl* m, string s) : pNode(n), pMtrl(m), sTex(s), nTex(-1){}
};


struct TfceIdx
{
	INT	n;
	TfceIdx() : n(0){}
	TfceIdx(INT T) : n(T){}
};


template<class T>
struct TsrtG																	// For sort... descendent Sort
{
		bool operator()(const T& t1,const T& t2) const	{ return t1.n < t2.n; }
};

typedef std::map<TfceIdx, INT,TsrtG<TfceIdx > >	mpTfce;
typedef mpTfce::iterator						itTfce;



// UV Packing��
struct _Tpck
{
	INT		T;		// T-face Index
	INT		G;		// Vertex Index
	FLOAT	U;		// Texture U
	FLOAT	V;		// Texture V

	_Tpck() : T(0), G(0), U(0), V(0){}
	_Tpck(INT _T,INT _G,FLOAT _U,FLOAT _V): T(_T), G(_G), U(_U), V(_V){}
};



struct LcHeader
{
	INT		nFrmB;					// Begin Frame
	INT		nFrmE;					// End Frame
	INT		nFrmP;					// Frame Rate(FPS)
	INT		nFrmT;					// Tick Frame

	INT		nGeo;					// Number of Geometry
	INT		nTex;					// Number of Texture File
	
	LcHeader()
	{
		nFrmB	= 0;
		nFrmE	= 0;
		nFrmP	= 0;
		nFrmT	= 0;

		nGeo	= 0;
		nTex	= 0;
	}
};


class LcMax : public SceneExport
{
public:
	LcMax();
	virtual ~LcMax();

	int				ExtCount();					// Number of extensions supported
	const TCHAR*	Ext(int n);					// Extension #n (i.e. "3DS")
	const TCHAR*	LongDesc();					// Long ASCII description (i.e. "Autodesk 3D Studio File")
	const TCHAR*	ShortDesc();				// Short ASCII description (i.e. "3D Studio")
	const TCHAR*	AuthorName();				// ASCII Author name
	const TCHAR*	CopyrightMessage();			// ASCII Copyright message
	const TCHAR*	OtherMessage1();			// Other message #1
	const TCHAR*	OtherMessage2();			// Other message #2
	unsigned int	Version();					// Version number * 100 (i.e. v3.01 = 301)
	void			ShowAbout(HWND hWnd);		// Show DLL's "About..." box
	
	BOOL			SupportsOptions(int ext, DWORD options);
	int				DoExport(const TCHAR*,ExpInterface*,Interface*, BOOL =FALSE, DWORD =0);


	static INT_PTR CALLBACK LcMaxOptionsDlgProc(HWND,UINT,WPARAM,LPARAM);

public:
	BOOL	m_bDoExport;
	
protected:
	ExpInterface*	m_pE;				// ExpInterface
	Interface*		m_pI;				// Interface
	BOOL			m_bS;				// Supress Prompt
	DWORD			m_dO;				// Options

	TCHAR			m_sFb[MAX_PATH];	// Export Binary File Name
	TCHAR			m_sFt[MAX_PATH];	// Export Text File Name
	TCHAR			m_sFl[MAX_PATH];	// Export Log File Name

	std::vector<INode*>	m_vMaxNode;		// �ƽ��� Node �ڷᱸ��
	std::vector<LcMtl>	m_vMaxMtrl;		// �ƽ��� Material
	std::vector<LcTex>	m_vMaxTexL;		// �ƽ��� Texture List
	std::set<string>	m_vMaxTexF;		// �ƽ��� Texture File Name List

	LcHeader		m_Header;			// Header
	LcGeo*			m_pGeo;				// Geometry Data

protected:
	void	GatherNode(INode*);			// Gather Node

	void	GatherTexture();				// Gather Texture
	void	GatherMaterial(INode*,Mtl*);	// Gather Material


	void	SetupIsBone(LcGeo*);		// Bone or Not
	void	SetupParentIndex(LcGeo*);	// Setup Parent Index
	void	SetupGeometry(LcGeo*);		// Setup Mesh
	void	SetupUV(LcGeo*);			// Setup UV Texture coordinate
	void	SetupAnimation(LcGeo*);		// Setup Animation

	INT		FindBoneId(INode*);			// Get Index of Node matched Geometry

	// For Animation
	void	SetupBoneWeight(LcGeo*);
	void	SetupPhysiqueWeight(LcGeo*,Modifier*);
	void	SetupSkinWeight(LcGeo*,Modifier*);
	void*	FindModifier(INode*,Class_ID);		//Physique=PHYSQ_CLASSID, skin=SKIN_CLASSID

	// For Texture and T-face
	void	DumpTexture(LcMtl*,Texmap*,INT);	//
	INT		SetupTextureIndex(LcGeo*);			// 
	INT		FindTextureIndex(string);			//


	void	WriteBinary();				// Export Binary
	void	WriteText();				// Export Text

	void	FileRename(char* pOut
				, char* pIn				// Original FullPath File Name
				, char* sFileName		// New File Name. if it is NULL, then The File Name will be Conserved.
				, char* sExt			// New Extension. if it is NULL, then The Extension will be Conserved.
				);


	void	MaxMatrixToD3D(D3DXMATRIX* pDst, Matrix3* pSrc, BOOL bIdentity=TRUE);

};



#endif

