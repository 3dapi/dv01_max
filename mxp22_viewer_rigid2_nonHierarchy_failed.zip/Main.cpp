// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_sClassName, "Mck");

	m_dRscMenu		= IDR_MENU;
	m_dRscAccel		= IDR_MAIN_ACCEL;

	m_dRscDevice	= IDM_CHANGEDEVICE;
	m_dRscToggle	= IDM_TOGGLEFULLSCREEN;
	m_dRscExit		= IDM_EXIT;

	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pGrid			= NULL;
	m_pLcMdl		= NULL;
}


HRESULT CMain::Init()
{
	D3DXFONT_DESC hFont =
	{
		14, 0, FW_NORMAL
		, 1, 0
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pD3DXFont) ) )
		return -1;

	SAFE_NEWCREATE1(	m_pInput,	CLcInput, m_hWnd	);
	SAFE_NEWCREATE1(	m_pCam,		CLcCam	, m_pd3dDevice);
	SAFE_NEWCREATE1(	m_pGrid,	CLcGrid	, m_pd3dDevice);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pLcMdl	);


	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	
	return S_OK;
}



HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);


	VEC3	vcDelta = m_pInput->GetMouseEps();

	FLOAT	fSpeedMov  = 200.f * m_fElapsedTime;
	FLOAT	fSpeedRot  =  0.1f;
	FLOAT	fSpeedWheel=  40.f * m_fElapsedTime;

	if(vcDelta.z !=0.f)
	{
		m_pCam->MoveForward(-vcDelta.z* fSpeedWheel, 1.f);
	}

	if(m_pInput->KeyState('W'))					// W
	{
		m_pCam->MoveForward( fSpeedMov, 1.f);
	}

	if(m_pInput->KeyState('S'))					// S
	{
		m_pCam->MoveForward(-fSpeedMov, 1.f);
	}

	if(m_pInput->KeyState('A'))					// A
	{
		m_pCam->MoveSideward(-fSpeedMov);
	}

	if(m_pInput->KeyState('D'))					// D
	{
		m_pCam->MoveSideward(fSpeedMov);
	}

	if(m_pInput->BtnPress(1))
	{
		m_pCam->Rotation(vcDelta.x, vcDelta.y, fSpeedRot);
	}


	SAFE_FRAMEMOVE(	m_pCam		);

	SAFE_FRAMEMOVE(	m_pLcMdl	);

	return S_OK;
}




HRESULT CMain::Render()
{
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF007799, 1.0f, 0L);


	SAFE_RENDER(	m_pGrid		);


	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,  D3DCULL_CCW);


	SAFE_RENDER(	m_pLcMdl	);

//	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	m_pd3dDevice->SetRenderState( D3DRS_FILLMODE,  D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	TCHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;
	
	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );

	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	if(m_pInput && m_pInput->MsgProc(hWnd, msg, wParam, lParam))
		return 0;
	
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);
	HMENU	hMenu = ::GetMenu(hWnd);	
	
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				RECT rc;
				HDC hDC = GetDC( hWnd );
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}


		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case ID_MNU_OPEN:
				{
					CHAR			sDir[MAX_PATH]="\0";
					OPENFILENAME	OFN;
					CHAR			sF[MAX_PATH];
					CHAR			sFullF[MAX_PATH]="";
					CHAR			InitDir[MAX_PATH]={0};
					
					GetCurrentDirectory(MAX_PATH, sDir);

					strcpy(InitDir, sDir);

					memset(&OFN, 0, sizeof(OFN));
					OFN.lStructSize = sizeof(OFN);
					OFN.hwndOwner=m_hWnd;
					OFN.lpstrFilter="Lcm Files(*.acm)\0*.acm\0All Files(*.*)\0*.*\0";
					OFN.lpstrFile=sFullF;
					OFN.nMaxFile=MAX_PATH;
					
					OFN.lpstrTitle="Choose the file...";
					OFN.lpstrFileTitle=sF;
					OFN.nMaxFileTitle=MAX_PATH;
					OFN.lpstrDefExt="Lcm";

					OFN.lpstrInitialDir	= InitDir;

					if( !GetOpenFileName(&OFN))
						return 0;

					SetCurrentDirectory(sDir);

					ILcmMdl*	pLcMdl	= NULL;


					// �ļ��� ���ؼ� �� �����͸� �����Ѵ�.
					if(SUCCEEDED(LcMdl_Create("Acm", &pLcMdl, m_pd3dDevice, sFullF, GDEVICE)))
					{
						SAFE_DELETE(m_pLcMdl);
						m_pLcMdl	= pLcMdl;
					}

					break;
				}

			}

			break;
		}	// case WM_COMMAND:
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}

