// Interface for the ILcmMdl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcmMdl_H_
#define _ILcmMdl_H_


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILcmMdl
{
	LC_CLASS_DESTROYER(	ILcmMdl	);

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual void	Destroy()=0;
	virtual INT		FrameMove()=0;
	virtual void	Render()=0;
};


INT LcMdl_Create(char* sCmd
				 , ILcmMdl** pData
				 , void* p1			// Original Source: Original Source�� NULL�̸� ���� ����
				 , void* p2=0		// Model File Name
				 , void* p3=0		// No Use
				 , void* p4=0		// No Use
				 );


#endif

