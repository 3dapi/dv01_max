// Interface for the ILcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcmAcm_H_
#define _LcmAcm_H_


typedef D3DXVECTOR2			VEC2;
typedef D3DXVECTOR3			VEC3;
typedef D3DXVECTOR4			VEC4;
typedef D3DXQUATERNION		QUAT;

typedef D3DXMATRIX			MATA;
typedef D3DMATERIAL9		DMTL;
typedef LPDIRECT3DTEXTURE9	PDTX;
typedef	LPDIRECT3DDEVICE9	PDEV;


#pragma warning(disable: 4530)
#pragma warning(disable: 4786)



typedef D3DXVECTOR3				VEC3;
typedef D3DXMATRIX				MATA;
typedef D3DXQUATERNION			QUAT;
typedef LPDIRECT3DDEVICE9		PDEV;


class CLcmAcm : public CLcmMdl
{
public:
	struct VtxIdx
	{
		WORD	a, b, c;
		VtxIdx(){	a=0; b=0; c=0;	}
		VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		enum	{FVF = (D3DFMT_INDEX16),};
	};


	struct VtxPos
	{
		VEC3	p;
		
		VtxPos()		: p(0,0,0){}
		VtxPos(FLOAT X,FLOAT Y,FLOAT Z) : p(0,0,0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};


	struct LcGeo
	{
		char			sName[32];	// Node Name
		INT				nType;		// 1:Geometry, 2: Bone, 0: Etc

		INT				nPrn;		// Parent Index
		LcGeo*			pPrn;		// Parent Node

		D3DXMATRIX		mtWld;		// World Matrix

		INT				nFce;		// Number of Face
		INT				nPos;		// Number of Position
		VtxIdx*			pFce;		// Face List
		VtxPos*			pPos;		// Position List

		INT				nAni;		// Number of Animation
		D3DXMATRIX*		pAni;		// Animation Matrix

		LcGeo()
		{
			memset(sName, 0, sizeof sName);
			nType	= 0;

			nPrn	= -1;					// �θ� ����
			pPrn	= NULL;

			nFce	= 0;
			nPos	= 0;
			pFce	= NULL;
			pPos	= NULL;

			nAni	= 0;
			pAni	= NULL;
		}

		~LcGeo()
		{
			if(pFce){	delete [] pFce; pFce = NULL;	}
			if(pPos){	delete [] pPos; pPos = NULL;	}
			if(pAni){	delete [] pAni; pAni = NULL;	}
		}
	};


	struct LcHeader
	{
		INT		nFrmB;					// Begin Frame
		INT		nFrmE;					// End Frame
		INT		nFrmP;					// Frame Rate(FPS)
		INT		nFrmT;					// Tick Fram

		INT		nGeo;					// Number of Geometry
		
		LcHeader()
		{
			nFrmB	= 0;
			nFrmE	= 0;
			nFrmP	= 0;
			nFrmT	= 0;

			nGeo	= 0;
		}
	};


	// Geometry Type
	enum ELcm
	{
		LCX_ETC		=0,
		LCX_MESH	=1,
		LCX_BONE	=2,

		LCM_TX_NAME			= 128,
		LCX_HDEADER_OFFSET	= 64,
	};


protected:
	PDEV		m_pDev;

	LcHeader	m_Header;			// Header
	LcGeo*		m_pGeo;				// Geometry Data

	DWORD		m_TimeB;			// Start Time
	DWORD		m_TimeC;			// Current Time
	INT			m_nAni;

	D3DXMATRIX	m_mtWld;

public:
	CLcmAcm();
	virtual ~CLcmAcm();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

protected:
	INT	LoadMdl(char* sFile);
};

#endif

