// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#define SAFE_DELETE(p)		{ if(p){ delete  p; p = NULL;	}	}
#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] p; p = NULL;	}	}



#include "_StdAfx.h"


LcMax::LcMax()
{
	m_bDoExport = FALSE;

	m_pE	= NULL;					// ExpInterface
	m_pI	= NULL;					// Interface
	m_bS	= NULL;					// Supress Prompt
	m_dO	= NULL;					// Options

	m_nGeo	= NULL;					// Number of Geometry
	m_pGeo	= NULL;					// Geometry Data
}

LcMax::~LcMax() 
{
}


int LcMax::ExtCount()					{	return 1;						}
const TCHAR *LcMax::Ext(int n)			{	return _T("acm");				}
const TCHAR *LcMax::LongDesc()			{	return _T("Galic Studio Lcm");	}
const TCHAR *LcMax::ShortDesc()			{	return _T("LcMax Lcm");			}
const TCHAR *LcMax::AuthorName()		{	return _T("Heesung Oh");		}
const TCHAR *LcMax::CopyrightMessage()	{	return _T("Copyleft All rights not reserved");	}
const TCHAR *LcMax::OtherMessage1()		{	return _T("");					}
const TCHAR *LcMax::OtherMessage2()		{	return _T("");					}
unsigned int LcMax::Version()			{	return 100;						}

void LcMax::ShowAbout(HWND hWnd)
{			
}

BOOL LcMax::SupportsOptions(int ext, DWORD options)
{
	return TRUE;
}



void LcMax::FileRename(char* pOut
				, char* pIn				// Original FullPath File Name
				, char* sFileName		// New File Name. if it is NULL, then The File Name will be Conserved.
				, char* sExt			// New Extension. if it is NULL, then The Extension will be Conserved.
				)
{
	char tDrive[_MAX_DRIVE]={0};
	char tDir[_MAX_DIR]={0};
	char tFile[_MAX_FNAME]={0};
	char tExt[_MAX_EXT]={0};
	
	_splitpath( pIn, tDrive, tDir, tFile, tExt );

	if(sFileName && sExt)
	{
		_makepath( pOut, tDrive, tDir, sFileName, sExt );
	}
	else if(sFileName && NULL == sExt)
	{
		_makepath( pOut, tDrive, tDir, sFileName, tExt );
	}

	else if(NULL == sFileName && sExt)
	{
		_makepath( pOut, tDrive, tDir, tFile, sExt );
	}

	else
	{
		_makepath( pOut, tDrive, tDir, sFileName, sExt );
	}
}



INT_PTR CALLBACK LcMax::LcMaxOptionsDlgProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static LcMax *imp = NULL;


	WPARAM wLoParam = LOWORD(wParam);
	WPARAM wHiParam = HIWORD(wParam);
	
	if( WM_INITDIALOG == uMsg)
	{
		imp = (LcMax *)lParam;
		CenterWindow(hWnd,GetParent(hWnd));
		return TRUE;
	}
	else if( WM_CLOSE == uMsg)
	{
		EndDialog(hWnd, 0);
		return TRUE;
	}

	
	else if( WM_COMMAND == uMsg)
	{
		if(imp && IDC_EXPORT == wLoParam)
		{
			imp->m_bDoExport = TRUE;
			SendMessage(hWnd, WM_CLOSE, 0, 0);
		}

		return TRUE;
	}

	return FALSE;
}




