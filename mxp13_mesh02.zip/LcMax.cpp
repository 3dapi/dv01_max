// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#define SAFE_DELETE(p)		{ if(p){ delete  p; p = NULL;	}	}
#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] p; p = NULL;	}	}


#include "_StdAfx.h"


int	LcMax::DoExport(const TCHAR *sFile,ExpInterface *ei,Interface *pi, BOOL suppressPrompts, DWORD options)
{
	INT		n = 0;
	INT		i =0;

	HWND	hWndPrn = pi->GetMAXHWnd();// = GetActiveWindow();

	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_MAIN), hWndPrn, (DLGPROC)LcMaxOptionsDlgProc, (LPARAM)this);

	if(FALSE == m_bDoExport)
		return FALSE;


	m_pE	= ei;
	m_pI	= pi;
	m_bS	= suppressPrompts;
	m_dO	= options;


	// 0. Prepare: ���� �̸� ����
	memset(m_sFb, 0, sizeof m_sFb);	// Export Binary File Name
	memset(m_sFt, 0, sizeof m_sFt);	// Export Text File Name
	memset(m_sFl, 0, sizeof m_sFl);	// Export Log File Name
	strcpy(m_sFb, sFile);


	// �����̸� �ҹ��� ��ȯ
	char *s = (char*)sFile;
	char *e = (char*)sFile;
	char *d = (char*)m_sFb;

	e+= strlen( m_sFb );
	for( ; s<e; ++s, ++d)
		*d = tolower(*s);


	// ���� �̸� ����
	FileRename(m_sFt, m_sFb, NULL, "act");
	FileRename(m_sFl, m_sFb, NULL, "acz");


	// 1. Gather Node
	INode*	pRoot = m_pI->GetRootNode();
	GatherNode(pRoot);


	// 2. Create and Setup Geometry
	if(FAILED(SetupGeometry()))
		return FALSE;


	// 3. Geometry�� �̿��� Binary ���Ϸ� ���
	WriteBinary();
	WriteText();


	SAFE_DELETE_ARRAY(	m_pGeo	);
	m_bDoExport = FALSE;
	return TRUE;
}



void LcMax::GatherNode(INode* pNode)
{
	if(!pNode)
		return;

	m_vMaxNode.push_back(pNode);

	INT iChild = pNode->NumberOfChildren();

	for(int i=0; i<iChild; ++i)
	{
		INode* pChild = pNode->GetChildNode(i);

		if(pChild)
			GatherNode(pChild);
	}
}



INT LcMax::SetupGeometry()
{
	INT	n;
	INT	i;


	m_nGeo = m_vMaxNode.size();

	if(m_nGeo<1)
		return -1;

	m_pGeo = new LcGeo[m_nGeo];

	for(n =0; n<m_nGeo; ++n)
	{
		LcGeo*	pGeo = &m_pGeo[n];
		INode*	pNode = m_vMaxNode[n];


		TCHAR*	sName  = pNode->GetName();
		INT		nChild = pNode->NumberOfChildren();


		sprintf(pGeo->sName, sName);


		Object* pObj = pNode->GetObjectRef();

		if(!pObj)
			continue;

		SClass_ID lSuperID = pObj->SuperClassID();
		Class_ID lClassID = pObj->ClassID();


		if(GEOMOBJECT_CLASS_ID != lSuperID)
			continue;

		if( BONE_OBJ_CLASSID == lClassID || Class_ID(BONE_CLASS_ID, 0) == lClassID)
			continue;

		// �޽��� �ﰢ������ �ٲ� �� �ִ°�?
		if(!pObj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
			continue;

		// �ﰢ������ �޽��� �ٲ۴�.
		TriObject* pTri = (TriObject *)pObj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
		if(NULL == pTri)
			continue;

		// �޽� ��ü�� ��´�.
		Mesh* pMesh	= &pTri->GetMesh();
		if(NULL ==pMesh)
			continue;


		// Setup Type
		pGeo->nType = 1;

		// �ε����� ������ ���ڸ� ��´�.
		INT	iNfce	= pMesh->getNumFaces();
		INT	iNvtx	= pMesh->getNumVerts();

		// Setup Index and Vertex Number
		pGeo->nFce = iNfce;
		pGeo->nPos = iNvtx;


		if(iNfce <1 || iNvtx <1)
			continue;
		

		// Index Vertex ����
		pGeo->pFce = new VtxIdx[iNfce];
		pGeo->pPos = new VtxPos[iNvtx];

	
		// �ε��� ������ ����
		for (i=0; i<iNfce; ++i)
		{
			pGeo->pFce[i].a = pMesh->faces[i].v[0];
			pGeo->pFce[i].b = pMesh->faces[i].v[1];
			pGeo->pFce[i].c = pMesh->faces[i].v[2];
		}

		// ���� ������ ����
		for (i=0; i<iNvtx; ++i)
		{
			Point3 v = pMesh->verts[i];
			pGeo->pPos[i].x = v.x;
			pGeo->pPos[i].y = v.y;
			pGeo->pPos[i].z = v.z;
		}
	}

	return 0;
}


void LcMax::WriteBinary()
{
	// Save Binary File

	INT n;

	FILE*	fp = fopen(m_sFb, "wb");
	fwrite(&m_nGeo, 1, sizeof(INT), fp);

	for(n =0; n<m_nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fwrite(pGeo->sName,  1, sizeof(char)*32, fp);	// Node Name
		fwrite(&pGeo->nType, 1, sizeof(INT ), fp);		// Node Type
		fwrite(&pGeo->nFce,  1, sizeof(INT ), fp);		// Index Number
		fwrite(&pGeo->nPos,  1, sizeof(INT ), fp);		// Vertex Number

		if(pGeo->nFce <1 || pGeo->nPos <1)
			continue;

		fwrite(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);
		fwrite(pGeo->pPos, pGeo->nPos, sizeof(VtxPos), fp);
	}

	fclose(fp);
}


void LcMax::WriteText()
{
	INT n, i;

	// Save Text File
	FILE*	fp = fopen(m_sFt, "wt");

	fprintf(fp, "\nTotal_Node: %d\n\n", m_nGeo);

	for(n =0; n<m_nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fprintf(fp, "Node_Name: %s, Type: %d\n", pGeo->sName, pGeo->nType);
		fprintf(fp, "Index_Vertex_Number: %4d %4d\n\n", pGeo->nFce, pGeo->nPos);

		if(pGeo->nFce <1 || pGeo->nPos <1)
			continue;
	
		fprintf(fp, "Face {\n");

		for (i=0; i<pGeo->nFce; ++i)
		{
			INT a, b, c;
			a = pGeo->pFce[i].a;
			b = pGeo->pFce[i].b;
			c = pGeo->pFce[i].c;

			fprintf(fp, "	%4d		%4d %4d %4d\n", i, a, b, c);
		}


		fprintf(fp, "}\n");


		fprintf(fp, "Vertex {\n");

		for (i=0; i<pGeo->nPos; ++i)
		{
			FLOAT x = pGeo->pPos[i].x;
			FLOAT y = pGeo->pPos[i].y;
			FLOAT z = pGeo->pPos[i].z;

			fprintf(fp, "	%4d		%12.5f %12.5f %12.5f\n", i, x, y, z);
		}

		fprintf(fp, "}\n\n");
	}

	fclose(fp);
}


