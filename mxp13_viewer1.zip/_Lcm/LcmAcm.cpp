// Implementation of the CLcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"
#include "LcmAcm.h"


#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] (p);	(p) = NULL;	} }
#define SAFE_RELEASE(p)		{ if(p){ (p)->Release(); (p) = NULL;} }







CLcmAcm::CLcmAcm()
{
	m_pDev	= NULL;

	m_nGeo	= 0;
	m_pGeo	= NULL;
}


CLcmAcm::~CLcmAcm()
{
	Destroy();
}


void CLcmAcm::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pGeo	);
}


INT CLcmAcm::Create(void* p1, void* p2, void* p3, void* p4)
{
	char*	sFile =(char*)p2;

	m_pDev	= (PDEV)p1;

	if(FAILED( LoadMdl(sFile)))
		return -1;

	return 0;
}


INT CLcmAcm::FrameMove()
{
	return 0;
}

void CLcmAcm::Render()
{
	INT		i=0;

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER , D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER , D3DTEXF_LINEAR);


	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);


	for(i=0; i<m_nGeo; ++i)
	{
		LcGeo*	pGeo	= &m_pGeo[i];

		if(pGeo->nFce <1 || pGeo->nPos <1)
			continue;
		
		m_pDev->SetTexture(0, NULL);

		m_pDev->SetFVF(VtxPos::FVF);
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
											, 0
											, pGeo->nPos
											, pGeo->nFce
											, pGeo->pFce
											, (D3DFORMAT)VtxIdx::FVF
											, pGeo->pPos
											, sizeof(VtxPos)	// D3DXGetFVFVertexSize(VtxPos::FVF)
											);
	}
}
	

INT CLcmAcm::LoadMdl(char* sFile)
{
	INT n;

	FILE* fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;


	fread(&m_nGeo, 1, sizeof(INT), fp);

	if(m_nGeo<1)
		return 0;


	m_pGeo = new LcGeo[m_nGeo];


	for(n =0; n<m_nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fread(pGeo->sName,  1, sizeof(char)*32, fp);	// Node Name
		fread(&pGeo->nType, 1, sizeof(INT ), fp);		// Node Type
		fread(&pGeo->nFce,  1, sizeof(INT ), fp);		// Index Number
		fread(&pGeo->nPos,  1, sizeof(INT ), fp);		// Vertex Number

		if(pGeo->nFce <1 || pGeo->nPos <1)
			continue;

		pGeo->pFce = new VtxIdx[pGeo->nFce];
		pGeo->pPos = new VtxPos[pGeo->nPos];

		fread(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);
		fread(pGeo->pPos, pGeo->nPos, sizeof(VtxPos), fp);
	}

	fclose(fp);

	return 0;
}


