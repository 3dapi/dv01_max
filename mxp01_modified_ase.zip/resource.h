//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by asdexp.rc
//
#define IDS_VERSION                     1
#define IDS_asdexp                    1
#define IDS_CATEGORY                    2
#define IDS_EXTENSION1                  3
#define IDS_LONGDESC                    4
#define IDS_SHORTDESC                   5
#define IDS_COPYRIGHT                   6
#define IDS_PROGRESS_MSG                7
#define IDS_VERSIONSTRING               8
#define IDS_LIBDESCRIPTION              9
#define IDD_PANEL                       101
#define IDD_ABOUTBOX                    102
#define IDD_asdexpORT_DLG             103
#define IDC_CLOSEBUTTON                 1000
#define IDC_MESHDATA                    1002
#define IDC_ANIMKEYS                    1003
#define IDC_MATERIAL                    1004
#define IDC_MESHANIM                    1005
#define IDC_NORMALS                     1006
#define IDC_TEXCOORDS                   1007
#define IDC_OBJ_GEOM                    1008
#define IDC_OBJ_SHAPE                   1009
#define IDC_OBJ_CAMLIGHT                1010
#define IDC_OBJ_CAMERA                  1010
#define IDC_OBJ_HELPER                  1011
#define IDC_CAMLIGHTANIM                1013
#define IDC_RADIO_USEKEYS               1016
#define IDC_RADIO_SAMPLE                1017
#define IDC_IKJOINTS                    1018
#define IDC_OBJ_LIGHT                   1019
#define IDC_VERTEXCOLORS                1020
#define IDC_BUTTON1                     1021
#define IDC_CONT_STEP                   1155
#define IDC_CONT_STEP_SPIN              1156
#define IDC_MESH_STEP                   1157
#define IDC_MESH_STEP_SPIN              1158
#define IDC_STATIC_FRAME                1161
#define IDC_STATIC_FRAME_SPIN           1162
#define IDC_PREC                        1163
#define IDC_PREC_SPIN                   1164

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
