// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#include "_StdAfx.h"


INT_PTR CALLBACK LcMaxOptionsDlgProc(HWND,UINT,WPARAM,LPARAM);



LcMax::LcMax()
{
	m_bDoExport = FALSE;

	m_pE	= NULL;					// ExpInterface
	m_pI	= NULL;					// Interface
	m_bS	= NULL;					// Supress Prompt
	m_dO	= NULL;					// Options
}

LcMax::~LcMax() 
{
}


int LcMax::ExtCount()					{	return 1;						}
const TCHAR *LcMax::Ext(int n)			{	return _T("acm");				}
const TCHAR *LcMax::LongDesc()			{	return _T("Galic Studio Lcm");	}
const TCHAR *LcMax::ShortDesc()			{	return _T("LcMax Lcm");			}
const TCHAR *LcMax::AuthorName()		{	return _T("Heesung Oh");		}
const TCHAR *LcMax::CopyrightMessage()	{	return _T("Copyleft All rights not reserved");	}
const TCHAR *LcMax::OtherMessage1()		{	return _T("");					}
const TCHAR *LcMax::OtherMessage2()		{	return _T("");					}
unsigned int LcMax::Version()			{	return 100;						}

void LcMax::ShowAbout(HWND hWnd)
{			
}

BOOL LcMax::SupportsOptions(int ext, DWORD options)
{
	return TRUE;
}


int	LcMax::DoExport(const TCHAR *sFile,ExpInterface *ei,Interface *pi, BOOL suppressPrompts, DWORD options)
{
	INT		n = 0;
	INT		i =0;

	HWND	hWndPrn = pi->GetMAXHWnd();// = GetActiveWindow();

	DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_MAIN), hWndPrn, (DLGPROC)LcMaxOptionsDlgProc, (LPARAM)this);

	if(FALSE == m_bDoExport)
		return FALSE;


	memset(m_sN, 0, sizeof m_sN);			// Export File Name
	m_pE	= ei;
	m_pI	= pi;
	m_bS	= suppressPrompts;
	m_dO	= options;

	strcpy(m_sN, sFile);

	
	FILE*	fp = fopen(m_sN, "wt");

	INode*	pRoot = m_pI->GetRootNode();
	
	GatherNode(pRoot);

	for(n =0; n<m_vMaxNode.size(); ++n)
	{
		INode*	pNode = m_vMaxNode[n];
		TCHAR*	sName  = pNode->GetName();
		INT		nChild = pNode->NumberOfChildren();

		if(pRoot == pNode->GetParentNode())
			fprintf(fp, "\n");

		fprintf(fp, "Node Name: %s, Child Number: %d\n", sName, nChild);


		Object* pObj = pNode->GetObjectRef();

		if(!pObj)
			continue;

		SClass_ID lSuperID = pObj->SuperClassID();
		Class_ID lClassID = pObj->ClassID();


		if(GEOMOBJECT_CLASS_ID != lSuperID)
			continue;

		if( BONE_OBJ_CLASSID == lClassID || Class_ID(BONE_CLASS_ID, 0) == lClassID)
			continue;

		// �޽��� �ﰢ������ �ٲ� �� �ִ°�?
		if(!pObj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0)))
			continue;

		// �ﰢ������ �޽��� �ٲ۴�.
		TriObject* pTri = (TriObject *)pObj->ConvertToType(0, Class_ID(TRIOBJ_CLASS_ID, 0));
		if(NULL == pTri)
			continue;

		// �޽� ��ü�� ��´�.
		Mesh* pMesh	= &pTri->GetMesh();
		if(NULL ==pMesh)
			continue;

		// ������ �ε����� ���ڸ� ��´�.
		INT	iNvtx	= pMesh->getNumVerts();
		INT	iNfce	= pMesh->getNumFaces();
	
		// �ε��� �����͸� ����Ѵ�.
		for (i=0; i<iNfce; ++i)
		{
			INT a, b, c;
			a = pMesh->faces[i].v[0];
			b = pMesh->faces[i].v[1];
			c = pMesh->faces[i].v[2];

			fprintf(fp, "	%4d %4d %4d\n", a, b, c);
		}

		// ���� �����͸� ����Ѵ�.
		for (i=0; i<iNvtx; ++i)
		{
			Point3 v = pMesh->verts[i];
			fprintf(fp, "	%12.5f %12.5f %12.5f\n", v.x, v.y, v.z);
		}

		fprintf(fp, "\n");
	}

	fclose(fp);


	m_bDoExport = FALSE;
	return TRUE;
}



void LcMax::GatherNode(INode* pNode)
{
	if(!pNode)
		return;

	m_vMaxNode.push_back(pNode);

	INT iChild = pNode->NumberOfChildren();

	for(int i=0; i<iChild; ++i)
	{
		INode* pChild = pNode->GetChildNode(i);

		if(pChild)
			GatherNode(pChild);
	}
}



























INT_PTR CALLBACK LcMaxOptionsDlgProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static LcMax *imp = NULL;


	WPARAM wLoParam = LOWORD(wParam);
	WPARAM wHiParam = HIWORD(wParam);
	
	if( WM_INITDIALOG == uMsg)
	{
		imp = (LcMax *)lParam;
		CenterWindow(hWnd,GetParent(hWnd));
		return TRUE;
	}
	else if( WM_CLOSE == uMsg)
	{
		EndDialog(hWnd, 0);
		return TRUE;
	}

	
	else if( WM_COMMAND == uMsg)
	{
		if(imp && IDC_EXPORT == wLoParam)
		{
			imp->m_bDoExport = TRUE;
			SendMessage(hWnd, WM_CLOSE, 0, 0);
		}

		return TRUE;
	}

	return FALSE;
}




