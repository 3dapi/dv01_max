
#pragma warning(disable: 4070)


#ifndef __StdAfx_H_
#define __StdAfx_H_


#include "Max.h"
#include "resource.h"

#include "stdmat.h"

#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"

#include "modstack.h"
#include "cs\Bipexp.h"
#include "cs\Phyexp.h"
#include "ISkin.h"

#include "LcMax.h"
#include "LcMaxClassDesc.h"


extern HINSTANCE g_hInst;
extern TCHAR *GetString(int id);

#endif __StdAfx_H_



