// Implementation of the CLcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILcmMdl.h"
#include "LcmMdl.h"
#include "LcmAcm.h"


#define SAFE_DELETE_ARRAY(p){ if(p){ delete [] (p);	(p) = NULL;	} }
#define SAFE_RELEASE(p)		{ if(p){ (p)->Release(); (p) = NULL;} }







CLcmAcm::CLcmAcm()
{
	m_pDev	= NULL;
	m_pGeo	= NULL;

	m_nAni	= 0;
}


CLcmAcm::~CLcmAcm()
{
	Destroy();
}


void CLcmAcm::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pGeo	);
}


INT CLcmAcm::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (PDEV)p1;

	if(FAILED( LoadMdl((char*)p2)))
		return -1;

	m_TimeB = GetTickCount();


	MATA mtS;
	MATA mtR;
	MATA mtT;

	D3DXMatrixScaling(&mtS, 3,3,3);
	D3DXMatrixRotationY(&mtR, D3DXToRadian(-30));
	D3DXMatrixTranslation(&mtT, 40, 0, 20);

	m_mtWld = mtS * mtR * mtT;
	return 0;
}


INT CLcmAcm::FrameMove()
{
	INT i;

	m_TimeC = GetTickCount();

	DWORD dTime = m_TimeC - m_TimeB;

	m_nAni = INT( dTime/m_Header.nFrmP);

	m_nAni %= m_Header.nFrmE;

	for(i=0; i<m_Header.nGeo; ++i)
	{
		LcGeo*	pCur = &m_pGeo[i];
		LcGeo*	pPrn = pCur->pPrn;

		D3DXMatrixIdentity(&pCur->mtWld);

		if(pPrn)
		{
			if(pCur->pAni)
				pCur->mtWld = pCur->pAni[m_nAni]* pPrn->mtWld;
			else
				pCur->mtWld = pCur->mtLcl * pPrn->mtWld;	// Node�� ���� ��� = Node�� ���� ��� * Node �θ��� ���� ���
		}
		else
			pCur->mtWld = m_mtWld;
	}

	return 0;
}

void CLcmAcm::Render()
{
	static	MATA mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

	INT		i=0;


	m_pDev->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);


	for(i=0; i<m_Header.nGeo; ++i)
	{
		LcGeo*	pGeo	= &m_pGeo[i];

		if(pGeo->nType != LCX_MESH || pGeo->nFce <1 || pGeo->nPos <1 )
			continue;
		

		m_pDev->SetTransform(D3DTS_WORLD, &pGeo->mtWld);
		m_pDev->SetTexture(0, NULL);

		m_pDev->SetFVF(VtxPos::FVF);
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
											, 0
											, pGeo->nPos
											, pGeo->nFce
											, pGeo->pFce
											, (D3DFORMAT)VtxIdx::FVF
											, pGeo->pPos
											, sizeof(VtxPos)	// D3DXGetFVFVertexSize(VtxPos::FVF)
											);
	}

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);	// ���� ��� ����
}
	

INT CLcmAcm::LoadMdl(char* sFile)
{
	INT n;

	FILE* fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;


	fread(&m_Header, 1, sizeof(LcHeader), fp);

	if(m_Header.nGeo<1)
		return 0;


	fseek(fp, LCX_HDEADER_OFFSET, SEEK_SET);

	m_pGeo = new LcGeo[m_Header.nGeo];


	// Read Mesh
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		fread(pGeo->sName,  1, sizeof(char)*32, fp);	// Node Name
		fread(&pGeo->nType, 1, sizeof(INT ), fp);		// Node Type
		fread(&pGeo->nFce,  1, sizeof(INT ), fp);		// Index Number
		fread(&pGeo->nPos,  1, sizeof(INT ), fp);		// Vertex Number

		fread(&pGeo->nPrn,  1, sizeof(INT ), fp);		// Parent Index
		fread(&pGeo->mtLcl, 1, sizeof(MATA), fp);		// Local Matrix
		fread(&pGeo->nAni,  1, sizeof(INT ), fp);		// Animation Number

		// �θ� ��� ����
		if(-1 != pGeo->nPrn)
			pGeo->pPrn = &m_pGeo[pGeo->nPrn];

		if(1 > pGeo->nFce || 1 > pGeo->nPos)
			continue;


		pGeo->pFce = new VtxIdx[pGeo->nFce];
		pGeo->pPos = new VtxPos[pGeo->nPos];

		fread(pGeo->pFce, pGeo->nFce, sizeof(VtxIdx), fp);
		fread(pGeo->pPos, pGeo->nPos, sizeof(VtxPos), fp);
	}


	// Read Animation
	for(n =0; n<m_Header.nGeo; ++n)
	{
		LcGeo* pGeo = &m_pGeo[n];

		if(1>pGeo->nAni)
			continue;

		pGeo->pAni = new MATA[pGeo->nAni];
		fread(pGeo->pAni, pGeo->nAni, sizeof(MATA), fp);	// Animation Matrix
	}

	fclose(fp);

	return 0;
}


