// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#include "_StdAfx.h"


UINT_PTR CALLBACK LcMaxOptionsDlgProc(HWND,UINT,WPARAM,LPARAM);

LcMax::LcMax()
{
}

LcMax::~LcMax() 
{
}

int LcMax::ExtCount()					{	return 1;						}
const TCHAR *LcMax::Ext(int n)			{	return _T("acm");				}
const TCHAR *LcMax::LongDesc()			{	return _T("Galic Studio Lcm");	}
const TCHAR *LcMax::ShortDesc()			{	return _T("LcMax Lcm");			}
const TCHAR *LcMax::AuthorName()		{	return _T("Heesung Oh");		}
const TCHAR *LcMax::CopyrightMessage()	{	return _T("Copyleft All rights not reserved");	}
const TCHAR *LcMax::OtherMessage1()		{	return _T("");					}
const TCHAR *LcMax::OtherMessage2()		{	return _T("");					}
unsigned int LcMax::Version()			{	return 100;						}

void LcMax::ShowAbout(HWND hWnd)
{			
}

BOOL LcMax::SupportsOptions(int ext, DWORD options)
{
	return TRUE;
}


int	LcMax::DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts, DWORD options)
{
	if(!suppressPrompts)
		DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_PANEL), GetActiveWindow(), (DLGPROC)LcMaxOptionsDlgProc, (LPARAM)this);

	return FALSE;
}




UINT_PTR CALLBACK LcMaxOptionsDlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	static LcMax *imp = NULL;
	
	switch(message)
	{
	case WM_INITDIALOG:
		imp = (LcMax *)lParam;
		CenterWindow(hWnd,GetParent(hWnd));
		return TRUE;
		
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		return TRUE;
	}
	return FALSE;
}




