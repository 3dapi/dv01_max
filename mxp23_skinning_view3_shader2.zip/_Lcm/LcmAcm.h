// Interface for the ILcmAcm class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcmAcm_H_
#define _LcmAcm_H_


typedef D3DXVECTOR2			VEC2;
typedef D3DXVECTOR3			VEC3;
typedef D3DXVECTOR4			VEC4;
typedef D3DXQUATERNION		QUAT;

typedef D3DXMATRIX			MATA;
typedef D3DMATERIAL9		DMTL;
typedef LPDIRECT3DTEXTURE9	PDTX;
typedef	LPDIRECT3DDEVICE9	PDEV;


typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;			// ID3DXEffect ��ü


#include <vector>

#pragma warning(disable: 4530)
#pragma warning(disable: 4786)



class CLcmAcm : public CLcmMdl
{
public:
	struct VtxIdx
	{
		WORD	a, b, c;
		VtxIdx(){	a=0; b=0; c=0;	}
		VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		enum	{FVF = (D3DFMT_INDEX16),};
	};


	struct VtxPos
	{
		VEC3	p;
		
		VtxPos()		: p(0,0,0){}
		VtxPos(FLOAT X,FLOAT Y,FLOAT Z) : p(0,0,0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};


	struct VtxBlend
	{
		VEC3		p;
		VEC2		t0;		// Texture Coordinate 0
		VEC2		t1;		// Texture Coordinate 1

		VEC4		g;		// BLEND WEIGHT
		VEC4		m;		// MATRIX INDEX

		VtxBlend() : p(0,0,0)
		{
			g[0]=g[1]=g[2]=g[3]=0;
			m[0]=m[1]=m[2]=m[3]=0;
		}

		enum {	FVF = (D3DFVF_XYZ | D3DFVF_TEX4 | \
						D3DFVF_TEXCOORDSIZE4(2) | D3DFVF_TEXCOORDSIZE4(3)),	};
	};


	struct Tbone
	{
		INT		nB;						// Bone Index
		FLOAT	fW;						// Weight

		Tbone() : nB(-1), fW(0.f){}
		Tbone(INT _B, FLOAT _W): nB(_B), fW(_W){}
	};

	struct LcmBone
	{
		std::vector<Tbone>	vB;			// Bone Index
	};


	struct LcGeo
	{
		char		sName[32];	// Node Name
		INT			nType;		// 1:Geometry, 2: Bone, 0: Etc

		INT			nPrn;		// Parent Index
		LcGeo*		pPrn;		// Parent Node

		INT			nFce;		// Number of Face
		INT			nVtx;		// Vertex Number
		DWORD		dFVF;		// Vertex Format
		UINT		dVtx;		// Stride of Vertex

		VtxIdx*		pFce;		// Face List
		void*		pVtx;		// Vertex

		INT			nBlnd;		// Bone�� ����޴� ���ؽ� ��
		LcmBone*	pBlnd;		// Dest
		
		INT			nAni;		// Number of Animation
		D3DXMATRIX*	pAni;		// Animation Matrix

		LcGeo()
		{
			memset(sName, 0, sizeof sName);
			nType	= 0;

			nPrn	= -1;					// �θ� ����
			pPrn	= NULL;

			nFce	= 0;
			nVtx	= 0;
			dFVF	= 0;
			dVtx	= 0;

			pFce	= NULL;
			pVtx	= NULL;

			nBlnd	= 0;
			pBlnd	= NULL;

			nAni	= 0;
			pAni	= NULL;
		}

		~LcGeo()
		{
			if(pFce){	delete [] pFce; pFce = NULL;	}
			if(pVtx){	free(pVtx);		pVtx = NULL;	}
			if(pAni){	delete [] pAni; pAni = NULL;	}
			if(pBlnd){	delete [] pBlnd; pBlnd = NULL;	}
		}
	};


	struct LcHeader
	{
		INT		nFrmB;					// Begin Frame
		INT		nFrmE;					// End Frame
		INT		nFrmP;					// Frame Rate(FPS)
		INT		nFrmT;					// Tick Fram

		INT		nGeo;					// Number of Geometry
		
		LcHeader()
		{
			nFrmB	= 0;
			nFrmE	= 0;
			nFrmP	= 0;
			nFrmT	= 0;

			nGeo	= 0;
		}
	};


	// Geometry Type
	enum ELcm
	{
		LCX_ETC		=0,
		LCX_MESH	=1,
		LCX_BONE	=2,

		LCX_HDEADER_OFFSET	= 64,
		LCM_MAX_BLEND		= 128,
	};


protected:
	PDEV		m_pDev;
	PDVD		m_pFVF0;			// ��������
	PDVD		m_pFVF1;			// ��������
	PDEF		m_pEft;				// ID3DXEffect ��ü

	LcHeader	m_Header;			// Header
	LcGeo*		m_pGeo;				// Geometry Data

	DWORD		m_TimeB;			// Start Time
	DWORD		m_TimeC;			// Current Time
	INT			m_nAni;

	D3DXMATRIX	m_mtBlnd[LCM_MAX_BLEND];	// Blending Matrix Buffer
	D3DXMATRIX	m_mtWld;			// World Matrix

public:
	CLcmAcm();
	virtual ~CLcmAcm();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* value);

protected:
	INT	LoadMdl(char* sFile);

};

#endif

