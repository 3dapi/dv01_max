// Interface for the LcMaxClassDesc class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif


#ifndef _LcMaxClassDesc_H_
#define _LcMaxClassDesc_H_



class LcMaxClassDesc:public ClassDesc2
{
public:
	int 			IsPublic();
	void *			Create(BOOL loading = FALSE);
	const TCHAR *	ClassName();
	SClass_ID		SuperClassID();
	Class_ID		ClassID();
	const TCHAR* 	Category();
	
	const TCHAR*	InternalName();
	HINSTANCE		HInstance();
	
};

#endif


