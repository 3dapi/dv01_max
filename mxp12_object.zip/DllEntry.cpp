// Implementation of the LcMax class.
//
////////////////////////////////////////////////////////////////////////////////



#include "_StdAfx.h"


HINSTANCE	g_hInst	=NULL;
int			g_controlsInit = FALSE;


ClassDesc2* GetLcMaxDesc();
TCHAR *GetString(int id);


__declspec( dllexport ) const TCHAR* LibDescription()	{	return GetString(IDS_LIBDESCRIPTION);	}
__declspec( dllexport ) int LibNumberClasses()			{	return 1;								}
__declspec( dllexport ) ClassDesc* LibClassDesc(int n)	{	return (0==n)? GetLcMaxDesc() : 0;		}
__declspec( dllexport ) ULONG LibVersion()				{	return VERSION_3DSMAX;					}


BOOL WINAPI DllMain(HINSTANCE hinst,ULONG,LPVOID)
{
	g_hInst = hinst;

	if (!g_controlsInit)
	{
		g_controlsInit = TRUE;
		InitCustomControls(g_hInst);	// Initialize MAX's custom controls
		InitCommonControls();			// Initialize Win95 controls
	}

	return (TRUE);
}






static LcMaxClassDesc g_LcMaxDesc;

ClassDesc2* GetLcMaxDesc()
{
	return &g_LcMaxDesc;
}

TCHAR *GetString(int id)
{
	static TCHAR buf[260]={0};

	if (g_hInst)
		return LoadString(g_hInst, id, buf, sizeof(buf)) ? buf : NULL;

	return NULL;
}